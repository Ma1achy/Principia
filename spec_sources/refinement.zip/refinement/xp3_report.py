"""Experiment 3 analysis: gate threshold vs control error and retention."""
import json, numpy as np, xp_reduce, xp3_gate

recs = json.load(open('xp_results/exp3_raw.json'))
ok = [r for r in recs if not r.get('_failed')]
print(f"records: {len(recs)} total, {len(ok)} usable, {len(recs)-len(ok)} failed\n")

NAME = {(c, cx, cy, bd): n for c, n, cx, cy, bd in xp3_gate.REGIONS}


def group(r):
    return (r['config'], r['cx'], r['cy'], r['body'], r['eta'])


keys = sorted({group(r) for r in ok})
rows = []
for k in keys:
    cfg, cx, cy, bd, eta = k
    grp = [r for r in ok if group(r) == k]
    for thr in xp3_gate.THRESHOLDS:
        a = xp_reduce.alphas(grp, 'E', thr)
        # retention + surviving footprints averaged over the jitter scales
        rets, fps = [], []
        for r in grp:
            st = xp_reduce.footprint_stats(r, thr)
            rets.append(st['retained_frac'])
            fps.append(st['n_footprints_surviving'])
        rows.append(dict(
            region=NAME[(cfg, cx, cy, bd)], config=cfg, eta=eta, thr=thr,
            alpha_ols2=a['ols2'], alpha_theil=a['theil'], n_scales=a['n_scales'],
            err_ols2=abs(a['ols2'] - 1.0) if np.isfinite(a['ols2']) else np.nan,
            err_theil=abs(a['theil'] - 1.0) if np.isfinite(a['theil']) else np.nan,
            retained=float(np.mean(rets)), fp_surv=float(np.mean(fps)),
        ))

json.dump(rows, open('xp_results/exp3_table.json', 'w'), indent=1)

# ---- per-region table at the production tolerance eta=0.01 ----
print("## Gate threshold vs control error and retention (eta=0.01)")
print("| region | thr | alpha_E (ols2) | alpha_E (theil) | |a_E-1| ols2 | retained | fp surviving /16 |")
print("|---|---|---|---|---|---|---|")
for r in rows:
    if r['eta'] != 0.01:
        continue
    flag = '' if (np.isfinite(r['err_ols2']) and r['err_ols2'] <= 0.05) else ' **!**'
    print(f"| {r['region']} | {r['thr']:.0e} | {r['alpha_ols2']:.4f}{flag} | "
          f"{r['alpha_theil']:.4f} | {r['err_ols2']:.4f} | {r['retained']:.3f} | {r['fp_surv']:.1f} |")

# ---- pooled knee ----
print("\n## Pooled over regions (eta=0.01)")
print("| thr | median |a_E-1| ols2 | median |a_E-1| theil | mean retained | worst region err |")
print("|---|---|---|---|---|")
for thr in xp3_gate.THRESHOLDS:
    sub = [r for r in rows if r['eta'] == 0.01 and r['thr'] == thr]
    e = np.array([r['err_ols2'] for r in sub], float)
    et = np.array([r['err_theil'] for r in sub], float)
    rt = np.array([r['retained'] for r in sub], float)
    print(f"| {thr:.0e} | {np.nanmedian(e):.4f} | {np.nanmedian(et):.4f} | "
          f"{np.nanmean(rt):.3f} | {np.nanmax(e):.4f} |")

# ---- eta interaction ----
print("\n## Interaction with integrator tolerance eta (pooled over regions)")
print("| eta | thr | median |a_E-1| | mean retained |")
print("|---|---|---|---|")
for eta in xp3_gate.ETAS:
    for thr in xp3_gate.THRESHOLDS:
        sub = [r for r in rows if r['eta'] == eta and r['thr'] == thr]
        if not sub:
            continue
        e = np.array([r['err_ols2'] for r in sub], float)
        rt = np.array([r['retained'] for r in sub], float)
        print(f"| {eta} | {thr:.0e} | {np.nanmedian(e):.4f} | {np.nanmean(rt):.3f} |")

# ---- raw drift distribution ----
print("\n## Drift distribution per region (eta=0.01, over all jitter scales)")
print("| region | median drift | max drift | n NaN drift | n traj |")
print("|---|---|---|---|---|")
for k in keys:
    if k[4] != 0.01:
        continue
    grp = [r for r in ok if group(r) == k]
    d = np.concatenate([np.asarray(r['drift'], float) for r in grp])
    print(f"| {NAME[k[:4]]} | {np.nanmedian(d):.2e} | {np.nanmax(d):.2e} | "
          f"{int(np.sum(~np.isfinite(d)))} | {len(d)} |")
