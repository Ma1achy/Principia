"""
EXPERIMENT D -- complete Brief 1's Experiment 2, and extend to t=240.

The 17 probes that returned nothing in Brief 1 all failed on the non-finite
step-budget burn that the tb_az patch fixes (measured: near-field t=60 child,
700 s timeout -> 17.1 s, a 41x speedup). They are now affordable.

xp_driver.Store keys on probe parameters, so pointing at the SAME store skips
the 23 probes that already succeeded and re-runs only the failures. Records
carrying '_failed' are dropped first so they can be re-attempted.

Value-ordered within each horizon: near-field first, because its escape fraction
was still climbing (0.00 -> 0.01 -> 0.56 across t=13/30/60) and it is the region
that would settle whether that saturates.
"""
import json, os, xp_driver

ORDER = [
    ('near-field',   1.0,  3.0, 0),
    ('mid-field',    1.0,  6.0, 0),
    ('body2 mid',    1.0, -5.0, 2),
    ('far r~10',     1.0, 13.0, 0),
    ('body1 slice', -2.0, -1.0, 1),
]
HORIZONS = [30.0, 60.0, 120.0, 240.0]      # t=13 all succeeded already
HALVES = [0.05, 0.025]
SYNC_INTERVAL = 0.4


def n_sync_for(t):
    return max(8, int(round(t / SYNC_INTERVAL)))


if __name__ == '__main__':
    path = 'xp_results/exp2_raw.json'
    recs = json.load(open(path))
    keep = [r for r in recs if not r.get('_failed')]
    print(f"store: {len(recs)} records, dropping {len(recs)-len(keep)} failed for re-attempt")
    json.dump(keep, open(path, 'w'))

    store = xp_driver.Store('exp2_raw.json')
    i, total = 0, len(HORIZONS) * len(ORDER) * len(HALVES)
    for t in HORIZONS:
        for name, cx, cy, bd in ORDER:
            for half in HALVES:
                i += 1
                r = xp_driver.probe(store, timeout=1800, config='burrau', cx=cx,
                                    cy=cy, body=bd, half=half, jf=0.5, t=t,
                                    eta=0.02, n_sync=n_sync_for(t))
                tag = 'cached' if r.get('_seconds') is None else r.get('_status')
                print(f"[{i}/{total}] t={t:.0f} {name} half={half} {tag} "
                      f"{r.get('_seconds')}s", flush=True)
        print(f"=== horizon t={t:.0f} complete, flushed ===", flush=True)
    print("EXP D DONE", flush=True)
