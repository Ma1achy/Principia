"""Round-trip meter, re-run after the COM-frame fix."""
import json, os, time, numpy as np, xp_nogate

REGIONS = [('burrau','near-field',1.0,3.0,0), ('burrau','mid-field',1.0,6.0,0),
           ('burrau','body2 core',1.0,-1.0,2), ('eq_rot','b0 core',0.0,1.0,0),
           ('eq_rot','b0 outer',0.0,3.0,0), ('eq_fast','b0 core',0.0,1.0,0)]
PATH='xp_results3/expB_roundtrip.json'
if __name__=='__main__':
    recs=json.load(open(PATH)) if os.path.exists(PATH) else []
    done={(r['config'],r['cx'],r['cy'],r['t']) for r in recs}
    for t in [13.0,40.0]:
        for cfg,name,cx,cy,bd in REGIONS:
            if (cfg,cx,cy,t) in done: continue
            t0=time.time()
            r=xp_nogate.run_probe(config=cfg,cx=cx,cy=cy,body=bd,half=0.05,t=t,ens=7,
                                  eta=0.01,n_sync=max(32,int(round(t/0.4))),reverse=True)
            r['_seconds']=round(time.time()-t0,1); r['_region']=name
            recs.append(r); json.dump(recs,open(PATH,'w'))
            e=xp_nogate.error_ratios(r)
            print(f"t={t:.0f} {cfg}/{name} {r['_seconds']}s rt={np.median(np.asarray(r['roundtrip'],float)):.3e} "
                  f"erMAX={e['error_ratio_max']:.4g} drift={np.nanmedian(np.asarray(r['drift'],float)):.2e}",flush=True)
    print("ROUNDTRIP DONE",flush=True)
