"""
EXPERIMENT 2 -- verify the float32 horizon.

The ~16 figure is ln(R/eps32)/lambda: the time for machine epsilon to grow to system
size. That is a REPRESENTABILITY horizon and it assumes the only float32 penalty is how
finely the state can be written down. Three arms separate that from everything else:

  f64          reference. Known-answer: alpha_E must be 1.0.
  f32-IC       float64 arithmetic, initial conditions rounded to float32. This is the
               representability horizon ALONE -- state written at eps32, evolved exactly.
  f32-arith    float32 throughout. Representability PLUS accumulated round-off.

If the ~16 prediction is right, f32-arith tracks f32-IC. If f32-arith breaks first, the
limit is arithmetic, not representability, and the fix is different (keep the accumulators
wide, not the grid coarse).

A fourth arm runs the softened leapfrog (tb.integrate) at both widths, because the
question behind this is which integrator a float32 GPU path should carry. AZ and leapfrog
are never compared to each other -- only each to itself across precision.

DRIVER VALIDITY: xp_prec.integrate_az_prec at float64 reproduces tb_az.integrate_az
bit-for-bit (max|dr| = 0 at t=5 and t=13). Verified before any float32 number was taken.
"""
import json, os, time
import numpy as np
import tb, xp_prec

REGIONS = [
    ('near-field', 1.0,  3.0, 0),
    ('mid-field',  1.0,  6.0, 0),
    ('body2 core', 1.0, -1.0, 2),
]
HORIZONS = [1.0, 2.0, 5.0, 8.0, 10.0, 12.0, 15.0, 20.0, 25.0]
JF = [0.25, 0.5]                      # 2x lever for the exponent
PATH = 'xp_results4/exp2_f32.json'

_mad = lambda x: 1.4826*np.median(np.abs(x - np.median(x)))


def sig(E, gid):
    """MAD spread, averaged over footprints. No gate; all E+1 copies."""
    return float(np.mean([_mad(E[gid == k]) for k in range(int(gid.max())+1)]))


def one(cx, cy, body, t, jf, arm):
    r0, v0, gid, _, hx = tb.burrau_grid(4, 4, cx, cy, 0.05, body=body, ens=7,
                                        jitter_frac=jf, seed=0)
    ns = max(1, int(round(t/0.4)))
    if arm == 'f32-IC':                      # representability only
        r0 = np.float32(r0).astype(np.float64); v0 = np.float32(v0).astype(np.float64)
    dt_ = np.float32 if arm == 'f32-arith' else np.float64
    R = np.asarray(r0, dt_); V = np.asarray(v0, dt_)
    if arm.startswith('lf'):
        dt_ = np.float32 if arm == 'lf32' else np.float64
        R = np.asarray(r0, dt_); V = np.asarray(v0, dt_)
        e2 = dt_(0.03)**2
        res = tb.integrate(R, V, t_max=t, dt=dt_(5e-4), eps=dt_(0.03))
        Ei = tb.energy(R, V, e2).astype(float)
        Ef = tb.energy(res['r'], res['v'], e2).astype(float)
    else:
        o = xp_prec.integrate_az_prec(R, V, t_max=t, n_sync=ns, eta=0.01, dtype=dt_)
        Ei = tb.energy(R, V, dt_(0.0)).astype(float)
        Ef = tb.energy(o['r'], o['v'], dt_(0.0)).astype(float)
    nf = float(np.mean(~np.isfinite(Ef)))
    Ef = np.where(np.isfinite(Ef), Ef, np.inf)
    return sig(Ei, gid), sig(Ef, gid), float(jf*hx), nf


ARMS = ['f64', 'f32-IC', 'f32-arith', 'lf64', 'lf32']

if __name__ == '__main__':
    recs = json.load(open(PATH)) if os.path.exists(PATH) else []
    done = {(r['region'], r['t'], r['arm']) for r in recs}
    i, total = 0, len(REGIONS)*len(HORIZONS)*len(ARMS)
    for name, cx, cy, bd in REGIONS:
        for t in HORIZONS:
            for arm in ARMS:
                i += 1
                if (name, t, arm) in done:
                    print(f"[{i}/{total}] cached", flush=True); continue
                t0 = time.time()
                vals = [one(cx, cy, bd, t, jf, arm) for jf in JF]
                s0, s1 = vals[0][1], vals[1][1]
                d0, d1 = vals[0][2], vals[1][2]
                with np.errstate(all='ignore'):
                    aE = float(np.log(s1/s0)/np.log(d1/d0)) if s0 > 0 and s1 > 0 else float('nan')
                rec = dict(region=name, t=t, arm=arm, alpha_E=aE,
                           error_ratio=float(vals[1][1]/vals[1][0]) if vals[1][0] > 0 else float('nan'),
                           sigma0=vals[1][0], sigma1=vals[1][1],
                           nonfinite=float(np.mean([v[3] for v in vals])),
                           _seconds=round(time.time()-t0, 1))
                recs.append(rec)
                json.dump(recs, open(PATH, 'w'))              # flush every point
                print(f"[{i}/{total}] {name:<11} t={t:<5} {arm:<10} "
                      f"aE={aE:+.3f} er={rec['error_ratio']:.3e} nf={rec['nonfinite']:.2f} "
                      f"{rec['_seconds']}s", flush=True)
    print("EXP 2 DONE", flush=True)
