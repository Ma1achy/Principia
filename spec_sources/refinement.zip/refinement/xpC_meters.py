"""
EXPERIMENT B -- are the two error meters independent, and do they track error?

Also tests two extras:
  Gamma       predicted REDUNDANT: Gamma = A*B*(H-E) by construction, so
              recovered from the Cartesian state it is energy error weighted
              by A*B -- the same information rescaled.
  round-trip  proposed THIRD meter: integrate to t, reverse v, integrate back,
              measure ||r_return - r_0|| in canonical units. Not a first
              integral, but parameter-free, and it sees phase error along the
              trajectory -- which conserves both E and Lz exactly and is
              therefore structurally invisible to the two ratio meters.
"""
import json, os, time, numpy as np
import xp_nogate

REGIONS = [
    ('burrau',  'near-field', 1.0,  3.0, 0),
    ('burrau',  'mid-field',  1.0,  6.0, 0),
    ('burrau',  'body2 core', 1.0, -1.0, 2),
    ('eq_rot',  'b0 core',    0.0,  1.0, 0),
    ('eq_rot',  'b0 outer',   0.0,  3.0, 0),
    ('eq_fast', 'b0 core',    0.0,  1.0, 0),
]
HORIZONS, ETAS = [13.0, 40.0, 80.0], [0.01, 0.005]
PATH = 'xp_results3/expB_meters.json'

if __name__ == '__main__':
    recs = json.load(open(PATH)) if os.path.exists(PATH) else []
    done = {(r['config'], r['cx'], r['cy'], r['t'], r['eta']) for r in recs}
    i, total = 0, len(REGIONS)*len(HORIZONS)*len(ETAS)
    for t in HORIZONS:
        for eta in ETAS:
            for cfg, name, cx, cy, bd in REGIONS:
                i += 1
                if (cfg, cx, cy, t, eta) in done:
                    print(f"[{i}/{total}] cached", flush=True); continue
                t0 = time.time()
                r = xp_nogate.run_probe(config=cfg, cx=cx, cy=cy, body=bd,
                                        half=0.05, t=t, ens=7, eta=eta,
                                        n_sync=max(32, int(round(t/0.4))),
                                        reverse=(eta == 0.01))
                r['_seconds'] = round(time.time()-t0, 1); r['_region'] = name
                recs.append(r); json.dump(recs, open(PATH, 'w'))
                e = xp_nogate.error_ratios(r)
                print(f"[{i}/{total}] t={t:.0f} eta={eta} {cfg}/{name} {r['_seconds']}s "
                      f"er={e['error_ratio']:.4g} erMAX={e['error_ratio_max']:.4g} "
                      f"lz={e['error_ratio_lz']:.4g}", flush=True)
    print("EXP B DONE", flush=True)
