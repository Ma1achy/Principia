#!/bin/sh
# Stop the Exp2 sweep once the t=60 horizon completes, before t=120 begins.
while true; do
  if grep -q "horizon t=60.0 complete" xp_results/exp2.log 2>/dev/null; then
    pkill -f xp2_horizon; sleep 1; pkill -f xp_probe
    echo "STOPPED after t=60 horizon" >> xp_results/exp2.log
    exit 0
  fi
  if ! pgrep -f xp2_horizon >/dev/null 2>&1; then
    echo "sweep exited on its own" >> xp_results/exp2.log; exit 0
  fi
  sleep 20
done
