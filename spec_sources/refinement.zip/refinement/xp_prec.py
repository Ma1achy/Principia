"""
EXPERIMENT 2 support -- Aarseth-Zare integration at a chosen float width.

The harness pins float64 in two places that are not physics: `to_reg` concatenates a
float64 zero column onto the state, and the step loop does `.astype(float)`. So a float32
run needs its own driver. It does NOT need its own physics: `tb_az.AZSystem.deriv`,
`.to_reg`, `.to_cartesian` and `tb_az.choose_reference` are reused VERBATIM -- they are
dtype-generic, and they are exactly the code where the brief's section 4 silent sign errors
lived. Only the bookkeeping loop is retranscribed.

KNOWN-ANSWER CONTROL. Run at dtype=float64 this must reproduce tb_az.integrate_az to
round-off. `control()` asserts that. If it ever fails, the float32 numbers below are
measuring my driver and not the arithmetic.

CAVEAT, stated rather than hidden: tb_az guards divisions with np.maximum(x, 1e-300).
1e-300 is not representable in float32 and flushes to 0, so under float32 the guard is
weaker than under float64. It only engages at exact coincidence, which is the triple
collision AZ cannot regularise in either width, so this does not affect the horizon
measurement -- but it is a real difference between the two arms.
"""
import numpy as np
import tb, tb_az


def integrate_az_prec(r0, v0, t_max, n_sync=32, eta=0.01, max_steps=30000,
                      M=None, dtype=np.float64):
    """Transcription of tb_az.integrate_az with every buffer at `dtype`."""
    Mv = (tb.M if M is None else M).astype(dtype)
    n = r0.shape[0]
    r = np.asarray(r0, dtype).copy()
    v = np.asarray(v0, dtype).copy()
    t = np.zeros(n, dtype)
    dmin = np.full(n, np.inf, dtype)
    E0 = tb.energy(r, v, dtype(0.0))

    for kk in range(n_sync):
        t_target = dtype((kk + 1)*t_max/n_sync)
        ref = tb_az.choose_reference(r)

        for a, b, c in tb_az.TRIPLES:
            sel = np.nonzero((ref == a) & (t < t_target - 1e-7))[0]
            if len(sel) == 0:
                continue
            sysm = tb_az.AZSystem(a, b, c, M=Mv)
            s, E = sysm.to_reg(r[sel], v[sel])
            s = s.astype(dtype); E = E.astype(dtype)      # to_reg appends a f64 zero column
            dt_left = (t_target - t[sel]).astype(dtype)

            A0 = np.maximum(np.einsum('sk,sk->s', s[:, 0:2], s[:, 0:2]), dtype(1e-30))
            B0 = np.maximum(np.einsum('sk,sk->s', s[:, 4:6], s[:, 4:6]), dtype(1e-30))
            dtau = (dtype(eta)*dt_left/(A0*B0)).astype(dtype)

            for _ in range(max_steps):
                bad = ~np.isfinite(s).all(axis=1)
                done = (s[:, 8] >= dt_left) | bad
                if done.all():
                    break
                h = (dtau*(~done).astype(dtype)).astype(dtype)[:, None]
                k1 = sysm.deriv(s, E)
                k2 = sysm.deriv(s + dtype(0.5)*h*k1, E)
                k3 = sysm.deriv(s + dtype(0.5)*h*k2, E)
                k4 = sysm.deriv(s + h*k3, E)
                s = (s + (h/dtype(6.0))*(k1 + dtype(2)*k2 + dtype(2)*k3 + k4)).astype(dtype)
                R1, R2, _, _ = sysm.phys_from_state(s)
                d1 = np.sqrt(np.einsum('sk,sk->s', R1, R1))
                d2 = np.sqrt(np.einsum('sk,sk->s', R2, R2))
                dmin[sel] = np.minimum(dmin[sel], np.minimum(d1, d2))

            rc, vc = sysm.to_cartesian(s)
            r[sel] = rc.astype(dtype); v[sel] = vc.astype(dtype)
            t[sel] = (t[sel] + np.minimum(s[:, 8], dt_left)).astype(dtype)

    drift = np.abs((tb.energy(r, v, dtype(0.0)) - E0)/np.maximum(np.abs(E0), 1e-30))
    return dict(r=r, v=v, drift=drift, dmin=dmin, t=t, E0=E0)


def control(t=5.0, n_sync=13, verbose=True):
    """Known-answer: dtype=float64 must reproduce the harness to round-off."""
    r0, v0, gid, _, hx = tb.burrau_grid(4, 4, 1.0, 6.0, 0.05, body=0, ens=7,
                                        jitter_frac=0.5, seed=0)
    a = tb_az.integrate_az(r0, v0, t_max=t, n_sync=n_sync, eta=0.01, max_steps=30000)
    b = integrate_az_prec(r0, v0, t_max=t, n_sync=n_sync, eta=0.01, max_steps=30000,
                          dtype=np.float64)
    dr = np.abs(a['r'] - b['r']).max()
    dv = np.abs(a['v'] - b['v']).max()
    if verbose:
        print(f"control t={t}: max|dr|={dr:.3e} max|dv|={dv:.3e} "
              f"scale={np.abs(a['r']).max():.3e}")
    return dr, dv
