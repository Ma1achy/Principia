"""Experiment 2 analysis: escape fraction vs horizon, and the t_end exponent."""
import json, numpy as np, estimators, xp_reduce, xp2_horizon

recs = json.load(open('xp_results/exp2_raw.json'))
ok = [r for r in recs if not r.get('_failed')]
bad = [r for r in recs if r.get('_failed')]
THR = 1e-3
NAME = {(c, cx, cy, bd): n for c, n, cx, cy, bd in xp2_horizon.REGIONS}

print(f"probes: {len(recs)} attempted, {len(ok)} usable, {len(bad)} failed")
for b in bad:
    print(f"  FAILED {NAME.get((b['config'],b['cx'],b['cy'],b['body']),'?')} "
          f"t={b.get('t')} half={b.get('half')}: {b.get('_failed')[:80]}")

# ---- escape fraction, over gated trajectories only ----
print("\n## Escape fraction vs horizon (parent quad half=0.05, gate 1e-3)\n")
print("| region | t=13 | t=30 | t=60 | t=120 | retained@t=120 | med drift @t=120 |")
print("|---|---|---|---|---|---|---|")
esc_tab = {}
for key, nm in NAME.items():
    cells, ret, dm = [], '-', '-'
    for t in xp2_horizon.HORIZONS:
        r = next((x for x in ok if (x['config'], x['cx'], x['cy'], x['body']) == key
                  and x['t'] == t and x['half'] == 0.05), None)
        if r is None:
            cells.append('-'); continue
        good = xp_reduce.gate(r, THR)
        cens = np.asarray(r['censored'], bool)
        f = float((~cens & good).sum() / max(good.sum(), 1))
        esc_tab[(nm, t)] = f
        cells.append(f"{f:.2f}")
        if t == 120.0:
            ret = f"{good.mean():.2f}"
            dm = f"{np.nanmedian(np.asarray(r['drift'],float)):.1e}"
    print(f"| {nm} | {' | '.join(cells)} | {ret} | {dm} |")

# ---- t_end exponent where escape fraction > 0.3 ----
def t_end_spread(rec, thr=THR, escaped_only=True):
    gid = np.asarray(rec['gid']); good = xp_reduce.gate(rec, thr)
    if escaped_only:
        good = good & ~np.asarray(rec['censored'], bool)
    te = np.asarray(rec['t_end'], float)
    E = np.asarray(rec['E_fin'], float)
    sp, spE, nfp = [], [], 0
    for k in range(int(gid.max()) + 1):
        s = np.nonzero((gid == k) & good)[0]
        if len(s) < 3:
            continue
        nfp += 1
        sp.append(np.std(te[s])); spE.append(np.std(E[s]))
    if not sp:
        return None
    return float(np.mean(sp)), float(np.mean(spE)), nfp

print("\n## t_end exponent, parent (half=0.05) vs child (half=0.025), escaped copies only\n")
print("| region | t | esc frac | fp parent | fp child | t_end spread P | t_end spread C | "
      "**alpha t_end** | alpha_E control | trust |")
print("|---|---|---|---|---|---|---|---|---|---|")
for key, nm in NAME.items():
    for t in xp2_horizon.HORIZONS:
        f = esc_tab.get((nm, t))
        if f is None or f <= 0.3:
            continue
        P = next((x for x in ok if (x['config'],x['cx'],x['cy'],x['body'])==key
                  and x['t']==t and x['half']==0.05), None)
        C = next((x for x in ok if (x['config'],x['cx'],x['cy'],x['body'])==key
                  and x['t']==t and x['half']==0.025), None)
        if P is None or C is None:
            continue
        sp, spc = t_end_spread(P), t_end_spread(C)
        if sp is None or spc is None:
            continue
        d = np.array([C['delta'], P['delta']])
        a_te = estimators.est_ols(d, np.array([spc[0], sp[0]]))
        a_E = estimators.est_ols(d, np.array([spc[1], sp[1]]))
        tr = 'ok' if xp_reduce.trustworthy(a_E) else '**UNTRUSTWORTHY**'
        print(f"| {nm} | {t:.0f} | {f:.2f} | {sp[2]}/16 | {spc[2]}/16 | {sp[0]:.4e} | "
              f"{spc[0]:.4e} | **{a_te:.4f}** | {a_E:.4f} | {tr} |")
