"""
No-discard probe and reduction (Brief 3).

NOTHING IS EVER EXCLUDED. Every footprint carries exactly E+1 copies at every
playhead. `drift` is still recorded, but only as a diagnostic -- it is never used
to filter. Trust is measured instead, by conserved-quantity ratios that carry no
threshold and no tuned constant:

    error_ratio    = sigma_E(t)  / sigma_E(0)
    error_ratio_lz = sigma_Lz(t) / sigma_Lz(0)

Each trajectory conserves its own E and Lz exactly, so the ensemble's SPREAD of
them is fixed at t=0 and must stay there. Any departure from 1.0 is accumulated
integration error.

NON-FINITE POLICY. A NaN has no rank, so median/MAD cannot absorb it
(np.median of anything containing NaN is NaN). Rather than discard -- which is
the thing this architecture exists to avoid -- non-finite values are mapped to
+inf. Rank-based measures tolerate inf while fewer than half the copies are
affected (observed worst case 4.7% at t=240), the footprint keeps all E+1
copies, and the rule is uniform across footprints. `std` then returns NaN
(inf - inf), which is the honest answer for std: it is undefined on a sample
containing a divergent member. MAD and the trimmed std both survive, because a
minority of +inf values cannot move a median or reach past a trimmed tail.
"""
import numpy as np


# ------------------------------------------------------------- dispersion ----
def _clean(x):
    """Map non-finite to +inf. Count-preserving; no value is removed."""
    x = np.asarray(x, float)
    return np.where(np.isfinite(x), x, np.inf)


def d_std(x):
    return float(np.std(_clean(x)))


def d_mad(x):
    x = _clean(x)
    return float(1.4826 * np.median(np.abs(x - np.median(x))))


def d_trim(x, frac):
    """Drop top/bottom `frac` BY VALUE (not by drift). Uniform in rule across
    footprints even though it drops points within each."""
    x = np.sort(_clean(x))
    n = len(x)
    k = int(np.floor(n * frac))
    return float(np.std(x[k:n - k])) if n - 2*k >= 2 else float(np.std(x))


def measures_for(ens):
    """trim fraction chosen so it actually trims: 12.5% at 8 copies (1/tail),
    10% at 16 copies (1/tail). At 8 copies a 10% trim drops nothing."""
    frac = 0.125 if ens + 1 <= 8 else 0.10
    return {'std': d_std, 'MAD': d_mad, f'trim{int(frac*1000)/10:g}': lambda x: d_trim(x, frac)}


# ------------------------------------------------------------------ probe ----
def run_probe(config, cx, cy, body, half=0.05, jf=0.5, t=13.0, N=4, ens=7,
              eta=0.01, n_sync=32, seed=0, max_steps=30000, reverse=False):
    """One quad, no gate. Stores L at t as well as at 0 -- xp_common.run_probe
    stores only L_init, which is why new integration is needed for Brief 3."""
    import tb, tb_all_az as AA, refine_test as R, xp_common

    cfg = xp_common.apply_config(config)
    r0, v0, gid, _, hx = tb.burrau_grid(N, N, cx, cy, half, body=body, ens=ens,
                                        jitter_frac=jf, seed=seed)
    if cfg['omega'] != 0.0:
        v0 = xp_common.rigid_rotation(r0, cfg['omega'])

    E_init = tb.energy(r0, v0, 0.0)
    L_init = xp_common.angular_momentum(r0, v0)

    res = AA.integrate_all_az(r0, v0, t_max=t, n_sync=n_sync, eta=eta,
                              max_steps=max_steps)

    n_hat = R.shape_vec(res['r'])
    cls = tb.classify(dict(r=res['r'], v=res['v']))
    joint = (cls < 3).astype(int) * 3 + res['binary_id']
    KE = 0.5 * np.einsum('k,nki->n', tb.M, res['v'] * res['v'])
    E_fin = tb.energy(res['r'], res['v'], 0.0)
    L_fin = xp_common.angular_momentum(res['r'], res['v'])

    out = dict(config=config, cx=cx, cy=cy, body=body, half=half, jf=jf, t=t,
               N=N, ens=ens, eta=eta, n_sync=n_sync, seed=seed, hx=float(hx),
               delta=float(jf * hx), gid=gid.tolist(),
               E_init=E_init.tolist(), E_fin=E_fin.tolist(),
               L_init=L_init.tolist(), L_fin=L_fin.tolist(),
               n_hat=n_hat.tolist(), joint=joint.tolist(), KE=KE.tolist(),
               cls=cls.tolist(),                      # escaper identity (3 = still bound)
               drift=res['drift'].tolist(),          # DIAGNOSTIC ONLY
               censored=res['censored'].tolist(), t_end=res['t_end'].tolist())

    if reverse:
        # Time-reversal round trip: integrate back and compare to the start.
        # Catches phase error along the trajectory, which conserves both E and Lz
        # exactly and is therefore invisible to the two ratio meters.
        back = AA.integrate_all_az(res['r'], -res['v'], t_max=t, n_sync=n_sync,
                                   eta=eta, max_steps=max_steps)
        import tb_ftle
        # MUST compare in the COM frame. tb_az.AZSystem.to_cartesian re-centres r
        # and v on the centre of mass every sync, while burrau_grid returns lab-frame
        # positions. Differencing them directly measures the constant COM offset
        # (~0.63 canonical units) and nothing else -- the round-trip then reads the
        # same value at t=0.5 as at t=80. Centre both sides first.
        def _com(x):
            m = tb.M[None, :, None]
            return x - (m*x).sum(axis=1, keepdims=True)/tb.M.sum()
        Rg0 = np.sqrt(np.maximum(tb_ftle.inertia(r0), 1e-300) / tb.M.sum())
        dd = _com(back['r']) - _com(r0)
        d = np.sqrt(np.einsum('nki,nki->n', dd, dd))
        out['roundtrip'] = (d / Rg0).tolist()        # canonical units
    return out


# -------------------------------------------------------------- reduction ----
def footprint_values(rec, field, meas):
    """One dispersion value per footprint, over ALL E+1 copies."""
    gid = np.asarray(rec['gid'])
    if field == 'E':
        a = np.asarray(rec['E_fin'], float)
    elif field == 'KE':
        a = np.asarray(rec['KE'], float)
    else:
        a = None
    out = []
    for k in range(int(gid.max()) + 1):
        s = np.nonzero(gid == k)[0]
        if field == 'shape':
            nh = _clean(np.asarray(rec['n_hat'], float)[s])
            out.append(float(meas(np.linalg.norm(nh - np.median(nh, axis=0), axis=1))))
        elif field == 'event':
            j = np.asarray(rec['joint'])[s]
            _, c = np.unique(j, return_counts=True)
            out.append(float((1.0 - c.max()/len(s)) / (1.0 - 1.0/len(s))))
        else:
            out.append(float(meas(a[s])))
    return np.array(out, float)


def error_ratios(rec):
    """Both meters, per footprint.

    THE STATISTIC MUST BE ROBUST. Under exact dynamics E_fin(i) = E_init(i) for
    every trajectory, so the two SETS are identical and *any* dispersion
    statistic gives exactly 1.0 -- the meter's calibration does not depend on the
    choice. But a std-based meter returns NaN as soon as one copy is non-finite,
    which is exactly the pathological footprint the meter exists to flag. So MAD
    is the primary reading and std is carried alongside to show the difference.
    """
    gid = np.asarray(rec['gid'])
    Ei, Ef = _clean(rec['E_init']), _clean(rec['E_fin'])
    Li, Lf = _clean(rec['L_init']), _clean(rec['L_fin'])

    def ratios(a0, a1, stat):
        out = []
        for k in range(int(gid.max()) + 1):
            s = np.nonzero(gid == k)[0]
            b = stat(a0[s])
            if b > 0:
                out.append(stat(a1[s]) / b)
        return out

    mad = lambda x: 1.4826*np.median(np.abs(x - np.median(x)))
    er, lz = ratios(Ei, Ef, mad), ratios(Li, Lf, mad)
    er_s, lz_s = ratios(Ei, Ef, np.std), ratios(Li, Lf, np.std)
    f = lambda v: float(np.median(v)) if v else float('nan')
    g = lambda v: float(np.max(v)) if v else float('nan')
    return dict(error_ratio=f(er), error_ratio_lz=f(lz),
                error_ratio_max=g(er), error_ratio_lz_max=g(lz),
                error_ratio_std=f(er_s), error_ratio_lz_std=f(lz_s),
                nonfinite=float(np.mean(~np.isfinite(np.asarray(rec['E_fin'], float)))))


def exponent(parent, child, field, meas):
    """alpha from the realised spread ratio, parent (half) vs child (half/2)."""
    import estimators
    sp = float(np.mean(footprint_values(parent, field, meas)))
    sc = float(np.mean(footprint_values(child, field, meas)))
    d = np.array([child['delta'], parent['delta']])
    return estimators.est_ols(d, np.array([sc, sp])), sp, sc
