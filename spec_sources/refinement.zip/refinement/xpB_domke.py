"""
EXPERIMENT A -- the dom_KE sweep.

Pure post-hoc over Brief 1's stored per-trajectory arrays, re-gated to 1e-4
(Brief 1's own calibration finding). No new integration: the patched tb_az was
verified to reproduce those arrays bit-identically.

Three quantities decide the question:
  win share       does KE take the max
  clip fraction   fraction of footprints with KE_spread/dom_KE > 1  (domain too small)
  occupancy       median KE_spread/dom_KE                            (ramp wasted if tiny)

A domain is DISPLAY-SENSIBLE if typical values occupy a usable part of the colour
ramp without heavy clipping: median occupancy in [0.05, 0.5] and clip < 5%.
A domain is CONFIGURATION-STABLE if KE's win share does not cross the 0.5
decision boundary anywhere inside the display-sensible band.
"""
import json, numpy as np, xp_reduce

DOMS = [0.125, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0]
CONFIGS = ['burrau', 'eq_rot', 'eq_fast']
THR, REF_JF = 1e-4, 0.5
OCC_LO, OCC_HI, CLIP_MAX = 0.05, 0.5, 0.05


def quad_key(r):
    return (r['config'], r['cx'], r['cy'], r['body'])


def load():
    return [x for x in json.load(open('xp_results/exp1_raw.json')) if not x.get('_failed')]


def footprints_for(recs, thr=THR, jf=REF_JF):
    """{quad_key: [footprint dicts]} at the reference jitter scale."""
    out = {}
    for r in recs:
        if r['jf'] != jf:
            continue
        out[quad_key(r)] = xp_reduce.footprint_stats(r, thr)['footprints']
    return out


def score(fps, dom_KE):
    """Winner shares + display-sanity for one quad at one dom_KE."""
    if not fps:
        return None
    wins = {c: 0 for c in xp_reduce.CONTRIBUTORS}
    occ = []
    for f in fps:
        o = f['KE_raw'] / dom_KE
        occ.append(o)
        v = {'shape': f['shape_raw'] / 2.0, 'event': f['event_norm'], 'KE': min(o, 1.0)}
        # KE is CLAMPED at 1.0 here: a display domain clips, it does not run away.
        # This is the substantive difference from Brief 1's sensitivity sweep.
        m = max(v.values())
        wins[[c for c, x in v.items() if x >= m - 1e-15][0]] += 1
    n = len(fps)
    occ = np.array(occ)
    return dict(n=n,
                wins={c: wins[c] / n for c in wins},
                wins_count=wins,
                clip=float(np.mean(occ > 1.0)),
                occ_med=float(np.median(occ)),
                occ_lo=float(np.percentile(occ, 10)),
                occ_hi=float(np.percentile(occ, 90)))


def display_sensible(clip, occ_med):
    return (clip < CLIP_MAX) and (OCC_LO <= occ_med <= OCC_HI)


if __name__ == '__main__':
    recs = load()
    fps = footprints_for(recs)

    # alpha_E per quad, gate 1e-4, both estimators
    alph = {}
    for k in fps:
        grp = [r for r in recs if quad_key(r) == k]
        a = xp_reduce.alphas(grp, 'E', THR)
        alph[k] = a

    rows = []
    for dom in DOMS:
        for k, f in fps.items():
            s = score(f, dom)
            if s is None:
                continue
            rows.append(dict(dom_KE=dom, config=k[0], cx=k[1], cy=k[2], body=k[3],
                             alpha_E_ols2=alph[k]['ols2'], alpha_E_theil=alph[k]['theil'],
                             trust=xp_reduce.trustworthy(alph[k]['ols2']), **s))
    json.dump(rows, open('xp_results2/expA_domke.json', 'w'), indent=1)
    print(f"wrote xp_results2/expA_domke.json: {len(rows)} (dom_KE x quad) rows, "
          f"{len(fps)} quads, gate {THR:.0e}, jf={REF_JF}")
