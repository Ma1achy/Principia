"""
EXPERIMENT A -- does the closed loop survive with nothing discarded?

Parent (half=0.05) vs child (half=0.025), exponent from the realised spread
ratio: the production-realistic two-scale case. No gate anywhere.
6 regions x 2 horizons x 2 copy counts x 2 quad sizes = 48 probes.
"""
import json, os, time, numpy as np
import xp_nogate

REGIONS = [
    ('burrau',  'near-field', 1.0,  3.0, 0),
    ('burrau',  'mid-field',  1.0,  6.0, 0),
    ('burrau',  'body2 core', 1.0, -1.0, 2),
    ('eq_rot',  'b0 core',    0.0,  1.0, 0),   # worst: error_ratio 3.7e+03
    ('eq_rot',  'b0 outer',   0.0,  3.0, 0),
    ('eq_fast', 'b0 core',    0.0,  1.0, 0),
]
HALVES, HORIZONS, ENS = [0.05, 0.025], [13.0, 40.0], [7, 15]
PATH = 'xp_results3/expA_nogate.json'


def n_sync_for(t):
    return max(32, int(round(t / 0.4)))


if __name__ == '__main__':
    recs = json.load(open(PATH)) if os.path.exists(PATH) else []
    done = {(r['config'], r['cx'], r['cy'], r['half'], r['t'], r['ens']) for r in recs}
    i, total = 0, len(REGIONS)*len(HALVES)*len(HORIZONS)*len(ENS)
    for t in HORIZONS:
        for ens in ENS:
            for cfg, name, cx, cy, bd in REGIONS:
                for half in HALVES:
                    i += 1
                    key = (cfg, cx, cy, half, t, ens)
                    if key in done:
                        print(f"[{i}/{total}] cached", flush=True); continue
                    t0 = time.time()
                    r = xp_nogate.run_probe(config=cfg, cx=cx, cy=cy, body=bd,
                                            half=half, t=t, ens=ens, eta=0.01,
                                            n_sync=n_sync_for(t))
                    r['_seconds'] = round(time.time()-t0, 1)
                    r['_region'] = name
                    recs.append(r)
                    json.dump(recs, open(PATH, 'w'))     # flush every probe
                    er = xp_nogate.error_ratios(r)
                    print(f"[{i}/{total}] t={t:.0f} ens={ens} {cfg}/{name} half={half} "
                          f"{r['_seconds']}s er={er['error_ratio']:.4g} "
                          f"lz={er['error_ratio_lz']:.4g} nf={er['nonfinite']:.3f}", flush=True)
    print("EXP A DONE", flush=True)
