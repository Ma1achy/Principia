"""
EXPERIMENT B -- is "ols2 fails while theil passes" recognisable at runtime?

Brief 1 finding 1(b): in the stressed eq_rot core, ols2 misses the alpha_E=1.0
ground truth at every gate threshold while Theil-Sen returns 0.86-1.05 on the
SAME data. Production uses ols2. If the failure condition has a runtime-detectable
signature, production can fall back selectively instead of paying for Theil-Sen
everywhere.

Pure post-hoc, pooled over exp1 (25 quad-groups x 4 scales) and exp3
(18 quad-groups x 5 scales). Gate 1e-4.
"""
import json, numpy as np, estimators, xp_reduce

THR, TOL = 1e-4, 0.05


def groups():
    out = {}
    for f, tag in [('xp_results/exp1_raw.json', 'exp1'), ('xp_results/exp3_raw.json', 'exp3')]:
        for r in json.load(open(f)):
            if r.get('_failed'):
                continue
            k = (tag, r['config'], r['cx'], r['cy'], r['body'], r['eta'])
            out.setdefault(k, []).append(r)
    return out


def diagnostics(grp):
    """Everything here is measurable at render time -- no ground truth used."""
    d = np.concatenate([np.asarray(r['drift'], float) for r in grp])
    fin = d[np.isfinite(d)]
    ret, nfp = [], []
    for r in grp:
        st = xp_reduce.footprint_stats(r, THR)
        ret.append(st['retained_frac'])
        nfp.append(st['n_footprints_surviving'])
    dd, ss = xp_reduce.spread_vs_delta(grp, 'E', THR)
    if len(dd) >= 3:
        x, y = np.log(dd), np.log(ss)
        b, a = np.polyfit(x, y, 1)
        resid = float(np.std(y - (a + b * x)))
    else:
        resid = np.nan
    return dict(
        retained=float(np.mean(ret)),
        min_fp=int(min(nfp)) if nfp else 0,
        max_drift=float(np.nanmax(d)),
        med_drift=float(np.nanmedian(d)),
        drift_ratio=float(np.nanmax(d) / max(np.nanmedian(d), 1e-30)),
        log_drift_iqr=float(np.subtract(*np.percentile(np.log10(np.maximum(fin, 1e-300)), [75, 25]))) if len(fin) else np.nan,
        n_nonfinite=int(np.sum(~np.isfinite(d))),
        fit_resid=resid,
    )


if __name__ == '__main__':
    rows = []
    for k, grp in groups().items():
        a = xp_reduce.alphas(grp, 'E', THR)
        o, t = a['ols2'], a['theil']
        ok_o = xp_reduce.trustworthy(o, TOL)
        ok_t = xp_reduce.trustworthy(t, TOL)
        rows.append(dict(src=k[0], config=k[1], cx=k[2], cy=k[3], body=k[4], eta=k[5],
                         alpha_ols2=o, alpha_theil=t, ols2_ok=ok_o, theil_ok=ok_t,
                         case=('both_ok' if ok_o and ok_t else
                               'ols2_fails_theil_ok' if ok_t else
                               'ols2_ok_theil_fails' if ok_o else 'both_fail'),
                         **diagnostics(grp)))
    json.dump(rows, open('xp_results2/expB_estimator.json', 'w'), indent=1)

    print(f"## B1. Cross-tabulation, {len(rows)} quad-groups, gate 1e-4, trust bar |alpha_E-1|<=0.05\n")
    print("| | theil passes | theil fails |")
    print("|---|---|---|")
    for oo in [True, False]:
        row = [sum(1 for r in rows if r['ols2_ok'] == oo and r['theil_ok'] == tt) for tt in [True, False]]
        print(f"| **ols2 {'passes' if oo else 'fails'}** | {row[0]} | {row[1]} |")

    n_sig = sum(1 for r in rows if r['case'] == 'ols2_fails_theil_ok')
    print(f"\nols2-fails-while-theil-passes: {n_sig}/{len(rows)} groups "
          f"({n_sig/len(rows):.0%}). Theil-Sen strictly better in these; the question is "
          f"whether they are identifiable without knowing alpha_E.\n")

    print("## B2. Do runtime-measurable diagnostics separate the cases?\n")
    keys = ['retained', 'min_fp', 'max_drift', 'drift_ratio', 'log_drift_iqr', 'fit_resid', 'n_nonfinite']
    print("| diagnostic | both_ok (median) | ols2_fails_theil_ok (median) | separation |")
    print("|---|---|---|---|")
    for kk in keys:
        A = np.array([r[kk] for r in rows if r['case'] == 'both_ok'], float)
        B = np.array([r[kk] for r in rows if r['case'] == 'ols2_fails_theil_ok'], float)
        if not len(B) or not len(A):
            continue
        ma, mb = np.nanmedian(A), np.nanmedian(B)
        # AUC: probability a random failing group scores higher than a random ok one
        pairs = [(b > a) + 0.5 * (b == a) for b in B for a in A if np.isfinite(b) and np.isfinite(a)]
        auc = float(np.mean(pairs)) if pairs else np.nan
        print(f"| {kk} | {ma:.4g} | {mb:.4g} | AUC {auc:.2f} |")

    print("\n## B3. The failing groups in full\n")
    print("| src | config | region centre | eta | alpha_ols2 | alpha_theil | retained | min fp | max drift | drift max/med | fit resid |")
    print("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in sorted(rows, key=lambda r: -abs(r['alpha_ols2'] - 1)):
        if r['case'] == 'both_ok':
            continue
        print(f"| {r['src']} | {r['config']} | ({r['cx']},{r['cy']}) b{r['body']} | {r['eta']} | "
              f"{r['alpha_ols2']:.3f} | {r['alpha_theil']:.3f} | {r['retained']:.2f} | {r['min_fp']} | "
              f"{r['max_drift']:.2e} | {r['drift_ratio']:.1e} | {r['fit_resid']:.4f} |")
