"""Reduction for Brief 4, Experiments 1-4. No gate anywhere; all E+1 copies."""
import json, os, sys
import numpy as np
import xp_nogate

R4 = 'xp_results4'
TOL = 0.05                      # |alpha_E - 1| > TOL == departed


def load(p):
    p = os.path.join(R4, p)
    return json.load(open(p)) if os.path.exists(p) else []


def sig(rec, field='E'):
    return float(np.mean(xp_nogate.footprint_values(rec, field, xp_nogate.d_mad)))


def alpha(s0, s1, d0, d1):
    if not (s0 > 0 and s1 > 0):
        return float('nan')
    return float(np.log(s1/s0)/np.log(d1/d0))


def fit_line(x, y):
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 2:
        return float('nan'), float('nan')
    A = np.vstack([x[ok], np.ones(ok.sum())]).T
    m, c = np.linalg.lstsq(A, y[ok], rcond=None)[0]
    return float(m), float(c)


def crossing(ts, dev, tol=TOL):
    """SUSTAINED departure: the first t from which |alpha_E - 1| exceeds tol and
    never comes back within it.

    First-exceedance is unusable here. alpha_E from a 2x lever carries about 0.07
    of scatter (a 5% error in the spread ratio divides by log 2), which straddles
    the 0.05 tolerance, so a single noisy point fires the detector and the curve
    then recovers -- near-field read 0.932 at t=20 and 1.003 at t=27. A horizon is
    a place you do not come back from; require that."""
    dev = np.asarray(dev, float)
    n = len(ts)
    for i in range(n):
        if np.isnan(dev[i]):
            return float(ts[i])                      # blew up outright
        if dev[i] > tol and all((d > tol) or np.isnan(d) for d in dev[i+1:]):
            return float(ts[i])
    return float('nan')


def alpha_global(recs_by_jf):
    """alpha from ALL jitter values at once (16x lever, ~8x less scatter than a
    2x pair). Loses delta-resolution, so it is reported alongside, not instead."""
    d = np.array([r['delta'] for r in recs_by_jf])
    s = np.array([sig(r) for r in recs_by_jf])
    ok = (s > 0) & np.isfinite(s)
    if ok.sum() < 2:
        return float('nan')
    m, _ = fit_line(np.log(d[ok]), np.log(s[ok]))
    return m


# ------------------------------------------- failure fraction (added late) ----
def bad_fraction(rec, thresh=1.05):
    """Fraction of footprints whose OWN error_ratio exceeds thresh.

    This is the statistic the t* tables should have been built on. A horizon
    located by thresholding an aggregate is a binary answer to a question that
    is not binary: footprints go bad one at a time, and the aggregate's verdict
    depends entirely on whether the aggregator is a mean (one bad footprint moves
    it) or a median (half of them must go). The fraction is aggregator-free."""
    gid = np.asarray(rec['gid'])
    Ei, Ef = xp_nogate._clean(rec['E_init']), xp_nogate._clean(rec['E_fin'])
    mad = lambda x: 1.4826*np.median(np.abs(x - np.median(x)))
    n = bad = 0
    for k in range(int(gid.max())+1):
        s = np.nonzero(gid == k)[0]
        b = mad(Ei[s])
        if b > 0:
            n += 1
            r = mad(Ef[s])/b
            if (not np.isfinite(r)) or r > thresh or r < 1.0/thresh:
                bad += 1
    return bad/max(n, 1), n


# ------------------------------------------------------------------ EXP 1 ----
def agg_alpha(rs, agg):
    """alpha_E across all jitters at once (16x lever), with the choice of how
    footprints are combined made EXPLICIT -- it turns out to decide the answer."""
    d = np.array([r['delta'] for r in rs])
    sv = np.array([agg(xp_nogate.footprint_values(r, 'E', xp_nogate.d_mad)) for r in rs])
    ok = (sv > 0) & np.isfinite(sv) & np.isfinite(d)
    if ok.sum() < 2:
        return float('nan')
    return fit_line(np.log(d[ok]), np.log(sv[ok]))[0]


def exp1(out):
    recs = load('exp1_jitter.json')
    if not recs:
        return
    order = [x['_region'] for x in recs]
    regions = sorted({r['_region'] for r in recs}, key=order.index)
    ts = sorted({r['t'] for r in recs})
    jfs = sorted({r['jf'] for r in recs})
    idx = {(r['_region'], r['t'], r['jf']): r for r in recs}
    got = lambda reg, t: [idx[(reg, t, jf)] for jf in jfs if (reg, t, jf) in idx]

    out.append("## Experiment 1 -- which wall binds\n")
    out.append(f"n = {len(recs)} probes. 5 jitter fractions {jfs} (16x span) at fixed "
               f"half=0.05, {len(regions)} regions, {len(ts)} horizons, ens=7 (8 copies), "
               "eta=0.01. No gate; every footprint keeps all 8 copies.\n")

    out.append("### 1a. alpha_E, 16x lever -- and the aggregator decides it\n")
    out.append("`sigma_E` per footprint (MAD over all 8 copies), then combined over the 16 "
               "footprints. Left column combines by MEAN, right by MEDIAN. Nothing else differs.\n")
    out.append("| region | " + " | ".join(f"t={t:g}" for t in ts) + " |")
    out.append("|---"*(len(ts)+1) + "|")
    for reg in regions:
        for lab, agg in (('mean', np.mean), ('median', np.median)):
            row = [f"{agg_alpha(got(reg, t), agg):+.3f}" for t in ts]
            out.append(f"| {reg} ({lab}) | " + " | ".join(row) + " |")
    out.append("")

    out.append("### 1b. error_ratio, median over footprints vs max over footprints\n")
    out.append("Both at jf=0.5. The median is the meter as specified; the max is the one "
               "Brief 3 recommended as a boolean flag.\n")
    out.append("| region | stat | " + " | ".join(f"t={t:g}" for t in ts) + " |")
    out.append("|---"*(len(ts)+2) + "|")
    for reg in regions:
        for key, lab in (('error_ratio', 'median'), ('error_ratio_max', 'max')):
            row = []
            for t in ts:
                r = idx.get((reg, t, jfs[-1]))
                row.append("-" if r is None else f"{xp_nogate.error_ratios(r)[key]:.4g}")
            out.append(f"| {reg} | {lab} | " + " | ".join(row) + " |")
    out.append("")

    out.append("### 1c. Failure FRACTION -- the aggregator-free statistic\n")
    out.append("Fraction of the 16 footprints whose own `error_ratio` falls outside "
               "[1/1.05, 1.05]. This is what 1a and 1b are each summarising differently. "
               "If a horizon is a wall this jumps 0 -> 1 at one t; if it is a rate it climbs.\n")
    rows = []
    for reg in regions:
        out.append(f"\n**{reg}** (fraction of 16 footprints failing)\n")
        out.append("| jf | delta | " + " | ".join(f"t={t:g}" for t in ts) + " |")
        out.append("|---"*(len(ts)+2) + "|")
        for jf in jfs:
            row, dl = [], np.nan
            for t in ts:
                r = idx.get((reg, t, jf))
                if r is None:
                    row.append("-"); continue
                f, _ = bad_fraction(r); dl = r['delta']
                rows.append((reg, np.log(dl), t, f))
                row.append(f"{f:.3f}")
            out.append(f"| {jf:g} | {dl:.3e} | " + " | ".join(row) + " |")
    out.append("")

    out.append("### 1d. Does the failure fraction depend on jitter?\n")
    out.append("The discriminating test. Regress the failure fraction on ln(delta) and on t "
               "together, pooled over regions. A measurement horizon needs a NEGATIVE ln(delta) "
               "coefficient (bigger jitter fails sooner); a noise-floor horizon needs a POSITIVE "
               "one; representability needs ZERO.\n")
    if rows:
        X = np.array([[r[1], r[2], 1.0] for r in rows])
        y = np.array([r[3] for r in rows])
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        res = y - X @ coef
        dof = max(len(y) - 3, 1)
        cov = np.linalg.pinv(X.T @ X) * (res @ res)/dof
        se = np.sqrt(np.diag(cov))
        out.append("| term | coefficient | std err | t-stat |")
        out.append("|---|---|---|---|")
        for nm, c, e in zip(['ln(delta)', 't', 'intercept'], coef, se):
            out.append(f"| {nm} | {c:+.5f} | {e:.5f} | {c/max(e,1e-30):+.2f} |")
        out.append(f"\nn = {len(y)} (region, jitter, horizon) cells.\n")
        pred = np.log(jfs[-1]/jfs[0])       # ln of the jitter span, = predicted shift if lambda=1
        out.append(f"Predicted shift across the 16x jitter span if the wall were "
                   f"jitter-set: ln(16)/lambda = {pred:.2f} time units. "
                   f"Measured ln(delta) coefficient: {coef[0]:+.5f} per e-fold "
                   f"(std err {se[0]:.5f}).\n")
    return rows


# ------------------------------------------------------------------ EXP 2 ----
def exp2(out):
    recs = load('exp2_f32.json')
    if not recs:
        return
    regions = sorted({r['region'] for r in recs})
    ts = sorted({r['t'] for r in recs})
    arms = ['f64', 'f32-IC', 'f32-arith', 'lf64', 'lf32']
    idx = {(r['region'], r['t'], r['arm']): r for r in recs}
    out.append("\n## Experiment 2 -- the float32 horizon\n")
    out.append(f"n = {len(recs)} points. `f32-IC` = float64 arithmetic with initial "
               "conditions rounded to float32 (representability alone). `f32-arith` = "
               "float32 throughout. `lf` = softened leapfrog, compared only to itself "
               "across precision.\n")
    out.append("Driver control: `xp_prec` at float64 reproduces `tb_az.integrate_az` "
               "bit-for-bit (max|dr| = 0.000e+00 at t=5 and t=13).\n")
    for reg in regions:
        out.append(f"\n### {reg} -- alpha_E\n")
        out.append("| arm | " + " | ".join(f"t={t:g}" for t in ts) + " | t\\* |")
        out.append("|---"*(len(ts)+2) + "|")
        for arm in arms:
            row, dev = [], []
            for t in ts:
                r = idx.get((reg, t, arm))
                a = r['alpha_E'] if r else np.nan
                row.append(f"{a:+.3f}" if np.isfinite(a) else "nan")
                dev.append(abs(a-1.0) if np.isfinite(a) else np.nan)
            tstar = crossing(ts, dev)
            ts_s = f"**{tstar:.1f}**" if np.isfinite(tstar) else f">{ts[-1]:g}"
            out.append(f"| {arm} | " + " | ".join(row) + f" | {ts_s} |")
    out.append("")


# ------------------------------------------------------------------ EXP 3 ----
def exp3(out):
    recs = load('exp3_escape.json')
    if not recs:
        return
    order = [x['_region'] for x in recs]
    regions = sorted({r['_region'] for r in recs}, key=order.index)
    ts = sorted({r['t'] for r in recs})
    out.append("\n## Experiment 3 -- is the escape statistic shadowing-robust?\n")
    out.append(f"n = {len(recs)} probes. Jitter ~1e-14 (round-off scale; measured "
               "sigma_E(0) = 3.95e-15), 5 seeds, 16 footprints x 8 copies = 128 "
               "trajectories each. No gate.\n")
    out.append("Copy 0 of every footprint is unjittered, hence bit-identical across seeds. "
               "It is EXCLUDED everywhere below -- including it would manufacture agreement "
               "that is not in the data.\n")
    out.append("Three columns, three different claims, deliberately not merged:\n")
    out.append("- **region fraction**: escapers / 112 over the whole region. The COARSE claim.\n")
    out.append("- **footprint fraction**: same fraction computed per footprint, then the "
               "across-seed spread averaged over footprints. The PER-PIXEL claim.\n")
    out.append("- **identity**: which body escapes. The FINE claim.\n")
    out.append("\n| region | t | region frac | across-seed sd | footprint-frac sd "
               "| identity agreement | majority identity stable |")
    out.append("|---|---|---|---|---|---|---|")
    for reg in regions:
        for t in ts:
            rs = [r for r in recs if r['_region'] == reg and r['t'] == t]
            if not rs:
                continue
            gfr, per_fp, agree, majs = [], [], [], []
            for r in rs:
                cls = np.asarray(r['cls']); gid = np.asarray(r['gid'])
                keep = np.ones(len(cls), bool); keep[::(r['ens']+1)] = False
                gfr.append(float(np.mean(cls[keep] < 3)))
                fp, mj = [], []
                for k in range(int(gid.max())+1):
                    sidx = np.nonzero((gid == k) & keep)[0]
                    fp.append(float(np.mean(cls[sidx] < 3)))
                    vals, cnt = np.unique(cls[sidx], return_counts=True)
                    mj.append(int(vals[cnt.argmax()])); agree.append(float(cnt.max()/len(sidx)))
                per_fp.append(fp); majs.append(mj)
            per_fp = np.array(per_fp); majs = np.array(majs)
            fpsd = float(np.mean(np.std(per_fp, axis=0)))
            stable = float(np.mean([len(set(majs[:, k])) == 1 for k in range(majs.shape[1])]))
            out.append(f"| {reg} | {t:g} | {np.mean(gfr):.4f} | {np.std(gfr):.4f} | "
                       f"{fpsd:.4f} | {np.mean(agree):.4f} | {stable:.2f} |")
    out.append("")
    return recs


# ------------------------------------------------------------------ EXP 4 ----
def exp4(out):
    recs = load('exp4_spacing.json')
    if not recs:
        return
    order = [x['_region'] for x in recs]
    regions = sorted({r['_region'] for r in recs}, key=order.index)
    ts = sorted({r['t'] for r in recs})
    halves = sorted({r['half'] for r in recs}, reverse=True)
    idx = {(r['_region'], r['t'], r['half']): r for r in recs}

    out.append("\n## Experiment 4 -- what a refinement level buys\n")
    out.append(f"n = {len(recs)} probes. Quad half-widths {halves} (8x span) at fixed "
               "jf=0.5, so delta = jf*2*half/(N-1) moves with the quad instead of with the "
               "jitter. Experiment 1 moved the same delta the other way; the two overlap "
               "exactly at half=0.05, jf=0.5.\n")

    out.append("### 4a. alpha_E, mean- vs median-aggregated over footprints\n")
    out.append("Exponent from adjacent half-width pairs (2x lever each).\n")
    out.append("| region | agg | delta (geo-mean) | " + " | ".join(f"t={t:g}" for t in ts) + " |")
    out.append("|---"*(len(ts)+3) + "|")
    for reg in regions:
        for lab, agg in (('mean', np.mean), ('median', np.median)):
            for i in range(len(halves)-1):
                h0, h1 = halves[i], halves[i+1]
                row, dc = [], np.nan
                for t in ts:
                    A, B = idx.get((reg, t, h1)), idx.get((reg, t, h0))
                    if A is None or B is None:
                        row.append("-"); continue
                    sa = agg(xp_nogate.footprint_values(A, 'E', xp_nogate.d_mad))
                    sb = agg(xp_nogate.footprint_values(B, 'E', xp_nogate.d_mad))
                    dc = np.sqrt(A['delta']*B['delta'])
                    row.append(f"{alpha(sa, sb, A['delta'], B['delta']):+.3f}")
                out.append(f"| {reg} | {lab} | {dc:.3e} | " + " | ".join(row) + " |")
    out.append("")

    out.append("### 4b. Failure fraction vs quad half-width\n")
    rows = []
    for reg in regions:
        out.append(f"\n**{reg}** (fraction of 16 footprints with error_ratio outside [1/1.05, 1.05])\n")
        out.append("| half | delta | " + " | ".join(f"t={t:g}" for t in ts) + " |")
        out.append("|---"*(len(ts)+2) + "|")
        for h in halves:
            row, dl = [], np.nan
            for t in ts:
                r = idx.get((reg, t, h))
                if r is None:
                    row.append("-"); continue
                f, _ = bad_fraction(r); dl = r['delta']
                rows.append((np.log(dl), t, f))
                row.append(f"{f:.3f}")
            out.append(f"| {h:g} | {dl:.3e} | " + " | ".join(row) + " |")
    out.append("")

    out.append("### 4c. The budgeting rule\n")
    out.append("Same regression as 1d, but delta is moved by the quad size rather than the "
               "jitter. The brief's rule -- halving the spacing buys ln(2)/lambda = 0.693 "
               "time units -- requires the ln(delta) coefficient to be non-zero and negative.\n")
    if rows:
        X = np.array([[r[0], r[1], 1.0] for r in rows]); y = np.array([r[2] for r in rows])
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        res = y - X @ coef
        cov = np.linalg.pinv(X.T @ X) * (res @ res)/max(len(y)-3, 1)
        se = np.sqrt(np.diag(cov))
        out.append("| term | coefficient | std err | t-stat |")
        out.append("|---|---|---|---|")
        for nm, c, e in zip(['ln(delta)', 't', 'intercept'], coef, se):
            out.append(f"| {nm} | {c:+.5f} | {e:.5f} | {c/max(e,1e-30):+.2f} |")
        out.append(f"\nn = {len(y)} (region, half-width, horizon) cells. "
                   f"Failure rate in t: {coef[1]:+.5f} per time unit "
                   f"(std err {se[1]:.5f}); a halving of delta shifts the fraction by "
                   f"{coef[0]*np.log(0.5):+.5f}, equivalent to "
                   f"{coef[0]*np.log(0.5)/coef[1] if abs(coef[1])>1e-12 else float('nan'):+.3f} "
                   "time units of playhead.\n")
    return rows


if __name__ == '__main__':
    out = ["# Brief 4 -- raw tables\n"]
    which = sys.argv[1:] or ['1', '2', '3', '4']
    if '1' in which: exp1(out)
    if '2' in which: exp2(out)
    if '3' in which: exp3(out)
    if '4' in which: exp4(out)
    txt = "\n".join(out)
    open(os.path.join(R4, 'tables.md'), 'w').write(txt)
    print(txt)
