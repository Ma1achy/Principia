"""Experiment A tables: does the closed loop survive with nothing discarded?"""
import json, numpy as np, xp_nogate as NG

recs = json.load(open('xp_results3/expA_nogate.json'))


def key(r):
    return (r['config'], r['_region'], r['t'], r['ens'])


pairs = {}
for r in recs:
    pairs.setdefault(key(r), {})[r['half']] = r

print("## A1. alpha_E with NOTHING discarded (true value exactly 1.0)\n")
print("| config | region | t | ens | non-finite | **std** | **MAD** | **trim** | error_ratio (P/C) | Lz meter |")
print("|---|---|---|---|---|---|---|---|---|---|")
rows = []
for k in sorted(pairs):
    d = pairs[k]
    if 0.05 not in d or 0.025 not in d:
        continue
    P, C = d[0.05], d[0.025]
    M = NG.measures_for(P['ens'])
    a = {}
    for nm, f in M.items():
        al, _, _ = NG.exponent(P, C, 'E', f)
        a[nm] = al
    eP, eC = NG.error_ratios(P), NG.error_ratios(C)
    nf = max(eP['nonfinite'], eC['nonfinite'])
    lz = 'undefined (0/0)' if not np.isfinite(eP['error_ratio_lz']) else f"{eP['error_ratio_lz']:.4g}"
    names = list(M)
    flag = lambda v: '' if (np.isfinite(v) and abs(v-1) <= 0.05) else ' !'
    print(f"| {k[0]} | {k[1]} | {k[2]:.0f} | {k[3]} | {nf:.3f} | "
          f"{a[names[0]]:.3f}{flag(a[names[0]])} | {a[names[1]]:.3f}{flag(a[names[1]])} | "
          f"{a[names[2]]:.3f}{flag(a[names[2]])} | "
          f"{eP['error_ratio']:.4g}/{eC['error_ratio']:.4g} | {lz} |")
    rows.append(dict(k=k, a=a, names=names, erP=eP['error_ratio'], erC=eC['error_ratio'],
                     lz=eP['error_ratio_lz'], nf=nf))

print("\n## A2. Pass rate against the trust bar |alpha_E - 1| <= 0.05\n")
print("| measure | t=13 | t=40 | ens=7 | ens=15 | overall |")
print("|---|---|---|---|---|---|")
for i, nm in enumerate(['std', 'MAD', 'trim']):
    def rate(sel):
        v = [r for r in rows if sel(r)]
        if not v: return '-'
        ok = sum(1 for r in v if np.isfinite(r['a'][r['names'][i]]) and abs(r['a'][r['names'][i]]-1) <= 0.05)
        return f"{ok}/{len(v)}"
    print(f"| {nm} | {rate(lambda r: r['k'][2]==13.0)} | {rate(lambda r: r['k'][2]==40.0)} | "
          f"{rate(lambda r: r['k'][3]==7)} | {rate(lambda r: r['k'][3]==15)} | {rate(lambda r: True)} |")

print("\n## A3. Does error_ratio predict which exponents are wrong?\n")
print("| error_ratio (worse of P/C) | n | MAD alpha_E passes |")
print("|---|---|---|")
for lo, hi, lab in [(0, 1.05, 'ratio < 1.05'), (1.05, 2.0, '1.05 - 2'),
                    (2.0, 100, '2 - 100'), (100, np.inf, '> 100')]:
    v = [r for r in rows if lo <= max(r['erP'], r['erC']) < hi]
    if not v: continue
    ok = sum(1 for r in v if np.isfinite(r['a']['MAD']) and abs(r['a']['MAD']-1) <= 0.05)
    print(f"| {lab} | {len(v)} | {ok}/{len(v)} |")

print("\n## A4. Do the contributor exponents survive? (shape / event, MAD, ens=7)\n")
print("| config | region | t | alpha_shape | alpha_event | alpha_E (MAD) |")
print("|---|---|---|---|---|---|")
for k in sorted(pairs):
    if k[3] != 7: continue
    d = pairs[k]
    if 0.05 not in d or 0.025 not in d: continue
    P, C = d[0.05], d[0.025]
    f = NG.d_mad
    ash, _, _ = NG.exponent(P, C, 'shape', f)
    aev, _, _ = NG.exponent(P, C, 'event', f)
    aE, _, _ = NG.exponent(P, C, 'E', f)
    print(f"| {k[0]} | {k[1]} | {k[2]:.0f} | {ash:.3f} | {aev:.3f} | {aE:.3f} |")
