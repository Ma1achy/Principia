"""
EXPERIMENT 3 -- is the escape statistic shadowing-robust?

The t=240 ionisation claims sit ~6.7x past the f64 horizon, so no individual trajectory
there is a trajectory of the real system. Escape is absorbing, though: once a body is
unbound and receding it stays that way, so the ENSEMBLE fraction may be reproducible even
when every individual outcome is not.

Test: perturb at round-off scale (jitter ~1e-14, six orders below the production jitter
and close to what f64 can even represent against coordinates of order 1) and vary the
seed. Anything that survives is a property of the region; anything that does not was an
artefact of one particular draw.

Two things are measured and they are not the same:
  frac_esc      per-footprint fraction of copies with a body escaping   -> the COARSE claim
  identity      WHICH body escapes                                      -> the FINE claim
The brief's prediction is that the first is stable while the second scrambles. Reported
separately so a split verdict is visible.

Copy 0 of every footprint is unjittered (burrau_grid sets mask[::reps] = False), so it is
bit-identical across seeds and is excluded from the cross-seed spread -- including it would
manufacture agreement that is not there.
"""
import json, os, time
import numpy as np
import xp_nogate

REGIONS = [
    ('near-field',  1.0,  3.0, 0),
    ('mid-field',   1.0,  6.0, 0),
    ('body2 mid',   1.0, -5.0, 2),
    ('body1 slice', -2.0, -1.0, 1),
]
HORIZONS = [20.0, 40.0, 80.0]
SEEDS = [0, 1, 2, 3, 4]
JF = 3e-13                 # jitter = JF * hx ~ 1e-14, i.e. round-off scale
PATH = 'xp_results4/exp3_escape.json'


def n_sync_for(t):
    return max(32, int(round(t / 0.4)))


if __name__ == '__main__':
    recs = json.load(open(PATH)) if os.path.exists(PATH) else []
    done = {(r['_region'], r['t'], r['seed']) for r in recs}
    i, total = 0, len(REGIONS)*len(HORIZONS)*len(SEEDS)
    for t in HORIZONS:
        for name, cx, cy, bd in REGIONS:
            for sd in SEEDS:
                i += 1
                if (name, t, sd) in done:
                    print(f"[{i}/{total}] cached", flush=True); continue
                t0 = time.time()
                r = xp_nogate.run_probe(config='burrau', cx=cx, cy=cy, body=bd,
                                        half=0.05, jf=JF, t=t, ens=7, eta=0.01,
                                        n_sync=n_sync_for(t), seed=sd)
                r['_seconds'] = round(time.time()-t0, 1)
                r['_region'] = name
                recs.append(r)
                json.dump(recs, open(PATH, 'w'))          # flush every probe
                cls = np.asarray(r['cls']); gid = np.asarray(r['gid'])
                fe = float(np.mean(cls < 3))
                print(f"[{i}/{total}] t={t:<5} {name:<12} seed={sd} {r['_seconds']}s "
                      f"esc_frac={fe:.4f}", flush=True)
    print("EXP 3 DONE", flush=True)
