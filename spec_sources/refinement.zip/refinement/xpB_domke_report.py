"""Experiment A tables."""
import json, numpy as np, xpB_domke as A, xp_reduce

rows = json.load(open('xp_results2/expA_domke.json'))
recs = A.load()
fps = A.footprints_for(recs)


def pooled(dom, cfg, trust_only=True):
    sub = [r for r in rows if r['dom_KE'] == dom and r['config'] == cfg
           and (r['trust'] or not trust_only)]
    if not sub:
        return None
    n = sum(r['n'] for r in sub)
    return dict(
        n=n, quads=len(sub),
        wins={c: sum(r['wins_count'][c] for r in sub) / n for c in xp_reduce.CONTRIBUTORS},
        clip=sum(r['clip'] * r['n'] for r in sub) / n,
        occ=float(np.median([r['occ_med'] for r in sub])))


print("## A1. dom_KE sweep, pooled per configuration (gate 1e-4, jf=0.5, trustworthy quads)\n")
print("| dom_KE | burrau winKE | eq_rot winKE | eq_fast winKE | clip (b/r/f) | occupancy (b/r/f) | display-sensible? |")
print("|---|---|---|---|---|---|---|")
for dom in A.DOMS:
    p = {c: pooled(dom, c) for c in A.CONFIGS}
    if any(v is None for v in p.values()):
        continue
    ds = [A.display_sensible(p[c]['clip'], p[c]['occ']) for c in A.CONFIGS]
    lab = 'all 3' if all(ds) else ('/'.join(c for c, d in zip(['b', 'r', 'f'], ds) if d) or 'none')
    print(f"| {dom} | {p['burrau']['wins']['KE']:.2f} | {p['eq_rot']['wins']['KE']:.2f} | "
          f"{p['eq_fast']['wins']['KE']:.2f} | "
          f"{p['burrau']['clip']:.2f}/{p['eq_rot']['clip']:.2f}/{p['eq_fast']['clip']:.2f} | "
          f"{p['burrau']['occ']:.3f}/{p['eq_rot']['occ']:.3f}/{p['eq_fast']['occ']:.3f} | {lab} |")

print("\n## A2. What wins instead, at each dom_KE (pooled over all 3 configs, trustworthy)\n")
print("| dom_KE | win shape | win event | win KE |")
print("|---|---|---|---|")
for dom in A.DOMS:
    sub = [r for r in rows if r['dom_KE'] == dom and r['trust']]
    n = sum(r['n'] for r in sub)
    w = {c: sum(r['wins_count'][c] for r in sub) / n for c in xp_reduce.CONTRIBUTORS}
    print(f"| {dom} | {w['shape']:.2f} | {w['event']:.2f} | {w['KE']:.2f} |")

print("\n## A3. Does KE's share cross the 0.5 boundary inside the display-sensible band?\n")
print("| config | display-sensible dom_KE values | winKE range across them | crosses 0.5? |")
print("|---|---|---|---|")
for cfg in A.CONFIGS:
    ok = [(d, pooled(d, cfg)) for d in A.DOMS]
    ok = [(d, p) for d, p in ok if p and A.display_sensible(p['clip'], p['occ'])]
    if not ok:
        print(f"| {cfg} | none | - | - |")
        continue
    ws = [p['wins']['KE'] for _, p in ok]
    crosses = min(ws) < 0.5 <= max(ws) or (min(ws) <= 0.5 < max(ws))
    print(f"| {cfg} | {', '.join(str(d) for d, _ in ok)} | {min(ws):.2f} - {max(ws):.2f} | "
          f"{'**YES**' if crosses else 'no'} |")

print("\n## A4. Per-quad KE win share (gate 1e-4), showing within-config scatter\n")
hdr = ' | '.join(f"/{d:g}" for d in A.DOMS)
print(f"| config | region | fp | alpha_E | trust | {hdr} |")
print('|---|---|---|---|---|' + '---|' * len(A.DOMS))
NAMES = {}
import xp_common
for c in xp_common.CONFIGS:
    for n, cx, cy, bd in xp_common.regions_for(c):
        NAMES[(c, cx, cy, bd)] = n
for k in sorted(fps, key=lambda k: (k[0], k[2])):
    per = []
    for d in A.DOMS:
        r = next((r for r in rows if r['dom_KE'] == d and (r['config'], r['cx'], r['cy'], r['body']) == k), None)
        per.append(f"{r['wins']['KE']:.2f}" if r else '-')
    r0 = next(r for r in rows if (r['config'], r['cx'], r['cy'], r['body']) == k)
    t = 'ok' if r0['trust'] else '**UNTR**'
    print(f"| {k[0]} | {NAMES.get(k,'?')} | {r0['n']} | {r0['alpha_E_ols2']:.3f} | {t} | {' | '.join(per)} |")

# clamped vs unclamped: does treating the domain as CLIPPING change the answer?
print("\n## A5. Clamping check — does treating dom_KE as a clipping display domain matter?\n")
print("| dom_KE | config | winKE clamped | winKE unclamped | differs |")
print("|---|---|---|---|---|")
for dom in [0.25, 1.0, 4.0, 16.0]:
    for cfg in A.CONFIGS:
        wc = wu = tot = 0
        for k, f in fps.items():
            if k[0] != cfg:
                continue
            for ff in f:
                o = ff['KE_raw'] / dom
                base = {'shape': ff['shape_raw'] / 2.0, 'event': ff['event_norm']}
                for clamp, acc in ((True, 'c'), (False, 'u')):
                    v = dict(base, KE=min(o, 1.0) if clamp else o)
                    m = max(v.values())
                    win = [c for c, x in v.items() if x >= m - 1e-15][0]
                    if win == 'KE':
                        if clamp: wc += 1
                        else:     wu += 1
                tot += 1
        print(f"| {dom} | {cfg} | {wc/tot:.4f} | {wu/tot:.4f} | "
              f"{'yes' if abs(wc-wu) > 0 else 'no'} |")
