"""
EXPERIMENT 4 -- what is a refinement level worth in playhead time?

Experiment 1 varies the jitter at fixed quad size; this varies the quad size at fixed
jitter fraction. Both move delta = jf * hx, hx = 2*half/(N-1), and by the same law -- so if
the horizon depends only on delta the two must agree at equal delta, whatever produced it.
That is a stronger check than either alone, and it is free: the two experiments already
overlap at half=0.05, jf=0.5.

4 half-widths spanning 8x, exponent from adjacent pairs (each a clean 2x lever), so each
alpha sits at a well-defined delta rather than being smeared across the whole range.
No gate; all E+1 copies retained.
"""
import json, os, time
import numpy as np
import xp_nogate

REGIONS = [
    ('near-field', 1.0, 3.0, 0),
    ('mid-field',  1.0, 6.0, 0),
]
HALVES = [0.1, 0.05, 0.025, 0.0125]
HORIZONS = [13.0, 20.0, 24.0, 27.0, 30.0, 33.0, 36.0, 40.0]
PATH = 'xp_results4/exp4_spacing.json'


def n_sync_for(t):
    return max(32, int(round(t / 0.4)))


if __name__ == '__main__':
    recs = json.load(open(PATH)) if os.path.exists(PATH) else []
    done = {(r['_region'], r['t'], r['half']) for r in recs}
    i, total = 0, len(REGIONS)*len(HALVES)*len(HORIZONS)
    for t in HORIZONS:
        for name, cx, cy, bd in REGIONS:
            for half in HALVES:
                i += 1
                if (name, t, half) in done:
                    print(f"[{i}/{total}] cached", flush=True); continue
                t0 = time.time()
                r = xp_nogate.run_probe(config='burrau', cx=cx, cy=cy, body=bd,
                                        half=half, jf=0.5, t=t, ens=7, eta=0.01,
                                        n_sync=n_sync_for(t))
                r['_seconds'] = round(time.time()-t0, 1)
                r['_region'] = name
                recs.append(r)
                json.dump(recs, open(PATH, 'w'))          # flush every probe
                sE = float(np.mean(xp_nogate.footprint_values(r, 'E', xp_nogate.d_mad)))
                er = xp_nogate.error_ratios(r)
                print(f"[{i}/{total}] t={t:<5} {name:<11} half={half:<7g} {r['_seconds']}s "
                      f"delta={r['delta']:.3e} sigE={sE:.4e} er={er['error_ratio']:.4g}",
                      flush=True)
    print("EXP 4 DONE", flush=True)
