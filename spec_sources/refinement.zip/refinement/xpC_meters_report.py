"""Experiment B tables."""
import json, numpy as np, xp_nogate as NG

recs = json.load(open('xp_results3/expB_meters.json'))
rows = []
for r in recs:
    e = NG.error_ratios(r)
    d = np.asarray(r['drift'], float)
    rt = np.asarray(r.get('roundtrip', []), float)
    rows.append(dict(cfg=r['config'], region=r['_region'], t=r['t'], eta=r['eta'],
                     er=e['error_ratio'], er_max=e['error_ratio_max'],
                     lz=e['error_ratio_lz'], lz_max=e['error_ratio_lz_max'],
                     nf=e['nonfinite'],
                     drift=float(np.nanmedian(d)),
                     rt=float(np.median(rt)) if rt.size else np.nan))

print("## B1. Both meters vs horizon and tolerance (median over footprints)\n")
print("| config | region | t | eta | error_ratio | er MAX | Lz ratio | Lz MAX | med drift | round-trip |")
print("|---|---|---|---|---|---|---|---|---|---|")
for r in sorted(rows, key=lambda r: (r['cfg'], r['region'], r['t'], -r['eta'])):
    lz = 'undef' if not np.isfinite(r['lz']) else f"{r['lz']:.4g}"
    lzm = 'undef' if not np.isfinite(r['lz_max']) else f"{r['lz_max']:.4g}"
    rt = '-' if not np.isfinite(r['rt']) else f"{r['rt']:.2e}"
    print(f"| {r['cfg']} | {r['region']} | {r['t']:.0f} | {r['eta']} | {r['er']:.4g} | "
          f"{r['er_max']:.4g} | {lz} | {lzm} | {r['drift']:.2e} | {rt} |")


def corr(a, b, log=True):
    a, b = np.asarray(a, float), np.asarray(b, float)
    m = np.isfinite(a) & np.isfinite(b) & (a > 0) & (b > 0)
    if m.sum() < 3:
        return np.nan, int(m.sum())
    x, y = (np.log10(a[m]), np.log10(b[m])) if log else (a[m], b[m])
    if np.std(x) == 0 or np.std(y) == 0:
        return np.nan, int(m.sum())
    return float(np.corrcoef(x, y)[0, 1]), int(m.sum())

print("\n## B2. Do the meters track integration error?\n")
print("| pair | correlation (log-log) | n |")
print("|---|---|---|")
for nm, a, b in [('error_ratio_max vs median drift', [r['er_max'] for r in rows], [r['drift'] for r in rows]),
                 ('Lz_max vs median drift',          [r['lz_max'] for r in rows], [r['drift'] for r in rows]),
                 ('round-trip vs median drift',      [r['rt'] for r in rows],     [r['drift'] for r in rows]),
                 ('**error_ratio_max vs Lz_max**',   [r['er_max'] for r in rows], [r['lz_max'] for r in rows]),
                 ('round-trip vs error_ratio_max',   [r['rt'] for r in rows],     [r['er_max'] for r in rows])]:
    c, n = corr(a, b)
    print(f"| {nm} | {c:+.3f} | {n} |" if np.isfinite(c) else f"| {nm} | n/a | {n} |")

print("\n## B3. Where is the Lz meter defined at all?\n")
print("| config | probes | Lz meter defined | reason |")
print("|---|---|---|---|")
for cfg in ['burrau', 'eq_rot', 'eq_fast']:
    sub = [r for r in rows if r['cfg'] == cfg]
    ok = sum(1 for r in sub if np.isfinite(r['lz']))
    why = 'released from rest: Lz=0 for every copy, sigma_Lz(0)=0' if cfg == 'burrau' else 'rotating: copies differ in Lz'
    print(f"| {cfg} | {len(sub)} | {ok}/{len(sub)} | {why} |")

print("\n## B4. Does tightening eta move each meter toward 1.0?\n")
print("| config | region | t | er MAX @eta=0.01 | @eta=0.005 | improves? |")
print("|---|---|---|---|---|---|")
for cfg, reg, t in sorted({(r['cfg'], r['region'], r['t']) for r in rows}):
    a = next((r for r in rows if (r['cfg'], r['region'], r['t'], r['eta']) == (cfg, reg, t, 0.01)), None)
    b = next((r for r in rows if (r['cfg'], r['region'], r['t'], r['eta']) == (cfg, reg, t, 0.005)), None)
    if not a or not b:
        continue
    if abs(a['er_max']-1) < 1e-9 and abs(b['er_max']-1) < 1e-9:
        continue
    imp = 'yes' if abs(b['er_max']-1) < abs(a['er_max']-1) else '**NO**'
    print(f"| {cfg} | {reg} | {t:.0f} | {a['er_max']:.4g} | {b['er_max']:.4g} | {imp} |")
