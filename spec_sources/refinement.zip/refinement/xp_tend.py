"""
EXPERIMENT C -- t_end with the escape-test cadence decoupled from the sync interval.

NEW MODULE. tb_all_az.py is NOT modified.

Brief 1 found tb_all_az assigns `t_end = t_now` at sync boundaries only
(tb_all_az.py:75), so t_end's resolution IS the sync interval. Measured: all 128
trajectories in mid-field t=30 carried t_end = 6.8 exactly = 17 x 0.4, giving a
within-footprint spread of zero BY CONSTRUCTION and an undefined exponent.

Here the escape test runs every `dt_test` (independent of any sync interval), and
when it first fires the crossing time is recovered by BISECTION inside that
interval rather than snapped to its upper boundary. Resolution becomes
dt_test / 2^n_bisect instead of the sync interval.

No Benettin shadow is carried: only t_end and the energy control are needed, so
the batch is half the size tb_all_az would integrate.

CAVEAT (stated in the report): bisection assumes the escape predicate is
monotonic within one dt_test window. It is not strictly -- a body can recede with
positive specific energy and later fall back. A small dt_test keeps this rare;
it is in any case far weaker an assumption than snapping to a 0.4-wide grid.
"""
import numpy as np
import tb, tb_az


def escaped(r, v, M=None):
    """Escape predicate, replicated from tb_all_az.py:59-75 so behaviour matches.
    Most-bound pair -> third body; escaping if its specific orbital energy wrt the
    binary is positive AND it is receding."""
    Mv = tb.M if M is None else M
    n = r.shape[0]
    pd = tb.pair_dists(r)
    third = np.array([2, 1, 0])[np.argmin(pd, axis=1)]
    out = np.zeros(n, dtype=bool)
    for b in range(3):
        sel = third == b
        if not sel.any():
            continue
        o = [q for q in range(3) if q != b]
        mb = Mv[o].sum()
        rc = (Mv[o[0]]*r[sel][:, o[0], :] + Mv[o[1]]*r[sel][:, o[1], :]) / mb
        vc = (Mv[o[0]]*v[sel][:, o[0], :] + Mv[o[1]]*v[sel][:, o[1], :]) / mb
        dr = r[sel][:, b, :] - rc
        dv = v[sel][:, b, :] - vc
        dist = np.sqrt(np.einsum('ij,ij->i', dr, dr))
        spec = 0.5*np.einsum('ij,ij->i', dv, dv) - mb/np.maximum(dist, 1e-12)
        out[np.nonzero(sel)[0]] = (spec > 0) & (np.einsum('ij,ij->i', dr, dv) > 0)
    return out


def _advance(r, v, dt, eta, max_steps):
    o = tb_az.integrate_az(r, v, t_max=dt, n_sync=1, eta=eta, max_steps=max_steps)
    return o['r'], o['v']


def integrate_tend(r0, v0, t_max, dt_test=0.05, eta=0.02, n_bisect=8,
                   max_steps=30000):
    """Returns t_end (NaN where never detected), censored, drift, and final state."""
    r, v = r0.copy(), v0.copy()
    n = r.shape[0]
    E0 = tb.energy(r, v, 0.0)
    t_end = np.full(n, np.nan)
    n_steps = int(np.ceil(t_max / dt_test))

    t_now = 0.0
    for _ in range(n_steps):
        step = min(dt_test, t_max - t_now)
        if step <= 0:
            break
        r_prev, v_prev = r.copy(), v.copy()
        r, v = _advance(r, v, step, eta, max_steps)
        t_next = t_now + step

        fired = escaped(r, v) & np.isnan(t_end)
        if fired.any():
            idx = np.nonzero(fired)[0]
            # bisect in [t_now, t_next] from the pre-step snapshot
            lo = np.zeros(len(idx))
            hi = np.full(len(idx), step)
            for _ in range(n_bisect):
                mid = 0.5*(lo + hi)
                # each trial re-integrates from the snapshot, so error does not accumulate
                rm, vm = r_prev[idx].copy(), v_prev[idx].copy()
                # advance each by its own mid: integrate_az takes a scalar t_max, so
                # scale by running the full max and stopping per-row is not possible.
                # Integrate each distinct mid separately -- they are few.
                em = np.zeros(len(idx), dtype=bool)
                for u in np.unique(mid):
                    m = mid == u
                    ru, vu = _advance(rm[m], vm[m], float(u), eta, max_steps)
                    em[m] = escaped(ru, vu)
                hi = np.where(em, mid, hi)
                lo = np.where(em, lo, mid)
            t_end[idx] = t_now + hi
        t_now = t_next

    drift = np.abs((tb.energy(r, v, 0.0) - E0) / np.maximum(np.abs(E0), 1e-30))
    censored = np.isnan(t_end)
    return dict(r=r, v=v, t_end=np.where(censored, t_max, t_end),
                censored=censored, drift=drift, T=t_max,
                resolution=dt_test / 2**n_bisect)
