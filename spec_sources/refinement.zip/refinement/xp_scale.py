"""
EXPERIMENT C -- canonical-unit length scales and the softening gauge.

AZ carries no softening, so this necessarily uses a softened leapfrog. Every
comparison here is rescaled-vs-not WITHIN this one integrator, so the
"never compare across integrators" rule is not violated; but the result is about
the gauge argument, not about the production integrator.

tb.accel and tb.energy take eps2 as `d2 + eps2`, which broadcasts against a
per-sample (N,) array -- so a per-trajectory, per-step eps needs no new physics.

THE SCALE GAUGE. Newtonian gravity is invariant under
    r -> a*r,   v -> a^-0.5*v,   t -> a^1.5*t
under which E -> E/a and Lz -> Lz*a^0.5. So E*a and Lz/a^0.5 are the
scale-quotiented invariants, and the shape vector n-hat is dimensionless.

THREE eps MODES
  absolute  fixed physical length             -- breaks the gauge
  initial   eps = c * Rg(0), c dimensionless  -- production semantics
  comoving  eps = c * Rg(t), recomputed       -- makes H time-dependent
"""
import numpy as np
import tb


def Rg(r, M=None):
    """Canonical length: sqrt(I/Mtot), the scale Principia sets to 1."""
    Mv = tb.M if M is None else M
    m = Mv[None, :, None]
    com = (m*r).sum(axis=1, keepdims=True)/Mv.sum()
    d = r - com
    return np.sqrt(np.einsum('k,nki->n', Mv, d*d)/Mv.sum())


def energy_eps(r, v, eps2):
    return tb.energy(r, v, eps2)


def integrate_soft(r0, v0, t_max, dt, c_eps, mode='initial'):
    """KDK leapfrog with softening in one of three gauges. Returns final state
    plus the softened energy and Lz at t=0 and t."""
    r, v = r0.copy(), v0.copy()

    def eps2_of(rr):
        if mode == 'absolute':
            return np.full(rr.shape[0], c_eps**2)
        if mode == 'initial':
            return (c_eps*Rg(r0))**2
        if mode == 'comoving':
            return (c_eps*Rg(rr))**2
        raise ValueError(mode)

    e2 = eps2_of(r)
    E0 = energy_eps(r, v, e2)
    L0 = (tb.M[None, :]*(r[..., 0]*v[..., 1] - r[..., 1]*v[..., 0])).sum(axis=1)

    a = tb.accel(r, e2)
    for _ in range(int(round(t_max/dt))):
        v += 0.5*dt*a
        r += dt*v
        e2 = eps2_of(r)                 # only 'comoving' actually changes
        a = tb.accel(r, e2)
        v += 0.5*dt*a

    E1 = energy_eps(r, v, eps2_of(r))
    L1 = (tb.M[None, :]*(r[..., 0]*v[..., 1] - r[..., 1]*v[..., 0])).sum(axis=1)
    return dict(r=r, v=v, E0=E0, E1=E1, L0=L0, L1=L1)


def rescale(r, v, a):
    """r -> a r, v -> a^-0.5 v. Time and dt must be scaled by a^1.5 by the caller."""
    return a*r, v/np.sqrt(a)
