"""
lambda, measured rather than assumed.

Every horizon in the brief is ln(something)/lambda, and lambda = 1 for Burrau is the
input, not an output. If lambda is really 0.5 every horizon doubles; if it is 2 they all
halve. Experiment 3's ensemble is the right instrument for it without any new integration:
it is seeded at ~1e-14, which is far enough below system size to leave room for many
e-folds before saturation, and it is sampled at t = 20, 40, 80.

Growth is measured on the shape vector n_hat, which is already scale-quotiented, so the
number does not depend on the size gauge. The t=80 point is checked for saturation and
dropped from the fit if the spread has reached order unity -- fitting through saturation
biases lambda downwards, which would silently make every horizon look longer.
"""
import json, os
import numpy as np

PATH = 'xp_results4/exp3_escape.json'
SAT = 0.1              # n_hat spread this large is approaching the shape sphere's extent


def spread(rec):
    gid = np.asarray(rec['gid']); nh = np.asarray(rec['n_hat'], float)
    nh = np.where(np.isfinite(nh), nh, np.nan)
    out = []
    for k in range(int(gid.max())+1):
        s = np.nonzero(gid == k)[0]
        out.append(np.nanmean(np.linalg.norm(nh[s] - np.nanmedian(nh[s], axis=0), axis=1)))
    return float(np.nanmedian(out))


if __name__ == '__main__':
    recs = json.load(open(PATH))
    regions = sorted({r['_region'] for r in recs},
                     key=[x['_region'] for x in recs].index)
    ts = sorted({r['t'] for r in recs})
    print(f"{'region':<13} " + " ".join(f"s(t={t:g})".rjust(11) for t in ts)
          + "   lambda   used  R_eff  t_f64  t_f32")
    for reg in regions:
        sv = []
        for t in ts:
            rs = [r for r in recs if r['_region'] == reg and r['t'] == t]
            sv.append(np.median([spread(r) for r in rs]) if rs else np.nan)
        sv = np.array(sv)
        s0 = 4e-15                                   # measured initial E-spread scale
        use = np.isfinite(sv) & (sv > 0) & (sv < SAT)
        tt = np.array(ts)
        if use.sum() >= 2:
            lam = np.polyfit(tt[use], np.log(sv[use]), 1)[0]
        elif use.sum() == 1:
            lam = float(np.log(sv[use][0]/s0)/tt[use][0])
        else:
            lam = np.nan
        drop = "".join('.' if u else 'X' for u in use)
        tf64 = np.log(1/2.22e-16)/lam if lam == lam and lam > 0 else np.nan
        tf32 = np.log(1/1.19e-7)/lam if lam == lam and lam > 0 else np.nan
        print(f"{reg:<13} " + " ".join(f"{v:11.3e}" for v in sv)
              + f"   {lam:6.3f}   {drop}   1.0  {tf64:5.1f}  {tf32:5.1f}")
    print("\nused: '.' = point in the fit, 'X' = dropped (non-finite, zero, or saturated"
          f" above {SAT})")
    print("t_f64 / t_f32 are ln(R/eps)/lambda at the MEASURED lambda, R = 1 canonical unit.")
