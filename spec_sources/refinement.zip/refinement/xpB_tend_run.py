"""EXPERIMENT C driver: t_end exponent with bisected escape times."""
import json, os, time, numpy as np
import xp_common, xp_tend, tb

REGIONS = [
    ('burrau',  'mid-field',  1.0,  6.0, 0, 13.0),
    ('burrau',  'body2 mid',  1.0, -5.0, 2, 13.0),
    ('eq_fast', 'b0 core',    0.0,  1.0, 0, 13.0),
    ('eq_fast', 'b1 core',   -1.0, -0.5, 1, 13.0),
    ('eq_fast', 'b2 core',    1.0, -0.5, 2, 13.0),
    ('burrau',  'near-field', 1.0,  3.0, 0, 60.0),   # only escapes by t=60
]
HALVES = [0.05, 0.025]
PATH = 'xp_results2/expC_tend.json'


def run_one(cfg, cx, cy, bd, half, t):
    xp_common.apply_config(cfg)
    r0, v0, gid, _, hx = tb.burrau_grid(4, 4, cx, cy, half, body=bd, ens=7,
                                        jitter_frac=0.5, seed=0)
    if xp_common.CONFIGS[cfg]['omega'] != 0.0:
        v0 = xp_common.rigid_rotation(r0, xp_common.CONFIGS[cfg]['omega'])
    res = xp_tend.integrate_tend(r0, v0, t_max=t, dt_test=0.05, eta=0.02, n_bisect=8)
    E = tb.energy(res['r'], res['v'], 0.0)
    return dict(config=cfg, cx=cx, cy=cy, body=bd, half=half, t=t,
                delta=float(0.5*hx), hx=float(hx), resolution=res['resolution'],
                gid=gid.tolist(), drift=res['drift'].tolist(),
                t_end=res['t_end'].tolist(), censored=res['censored'].tolist(),
                E_fin=E.tolist())


if __name__ == '__main__':
    recs = json.load(open(PATH)) if os.path.exists(PATH) else []
    done = {(r['config'], r['cx'], r['cy'], r['half'], r['t']) for r in recs}
    for cfg, name, cx, cy, bd, t in REGIONS:
        for half in HALVES:
            if (cfg, cx, cy, half, t) in done:
                print(f"cached {cfg}/{name} half={half}", flush=True); continue
            t0 = time.time()
            r = run_one(cfg, cx, cy, bd, half, t)
            r['_seconds'] = round(time.time()-t0, 1)
            recs.append(r)
            json.dump(recs, open(PATH, 'w'))       # flush after every probe
            print(f"{cfg}/{name} half={half} t={t} {r['_seconds']}s "
                  f"esc={1-np.mean(r['censored']):.2f}", flush=True)
    print("EXP C DONE", flush=True)
