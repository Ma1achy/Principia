"""
EXPERIMENT 2 supplement -- t_end at finer sync resolution.

t_end is assigned at sync boundaries only (tb_all_az.py:75, t_end = t_now), so
its resolution equals t_max/n_sync = 0.4 with the brief's settings. Measured:
all 128 trajectories in mid-field t=30 share t_end = 6.8 exactly = 17 x 0.4.
The within-footprint spread is therefore 0 BY CONSTRUCTION and the exponent is
undefined -- which is a property of the instrument, not of the field.

This re-runs the escaping regions with the sync interval cut from 0.4 to 0.05
and 0.0125 to see whether a t_end signal exists below the original resolution.
"""
import xp_driver

REGIONS = [('mid-field', 1.0, 6.0, 0), ('body2 mid', 1.0, -5.0, 2)]
INTERVALS = [0.05, 0.0125]
HALVES = [0.05, 0.025]
T = 13.0

if __name__ == '__main__':
    store = xp_driver.Store('exp2b_raw.json')
    for iv in INTERVALS:
        ns = int(round(T / iv))
        for name, cx, cy, bd in REGIONS:
            for half in HALVES:
                r = xp_driver.probe(store, timeout=900, config='burrau', cx=cx, cy=cy,
                                    body=bd, half=half, jf=0.5, t=T, eta=0.02, n_sync=ns)
                print(f"sync={iv} n_sync={ns} {name} half={half} "
                      f"{r.get('_status')} {r.get('_seconds')}s", flush=True)
        print(f"--- sync interval {iv} complete, flushed", flush=True)
    print("EXP2B PROBES DONE", flush=True)
