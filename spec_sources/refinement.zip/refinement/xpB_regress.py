"""
Known-answer control on the Brief 2 re-analysis path.

Everything in Experiments A and B is a post-hoc reduction of Brief 1's stored
per-trajectory arrays. Before any new number is believed, reproduce Brief 1's
published KE win-shares (REPORT.md, "Sensitivity of KE win-share") from that same
data through the same code path. If this does not match, the reduction is wrong
and nothing downstream counts.
"""
import json, numpy as np, xp_reduce

EXPECTED = {           # REPORT.md, gate 1e-3, all footprints incl. untrustworthy quads
    0.5:  dict(burrau=0.96, eq_rot=0.84, eq_fast=1.00),
    1.0:  dict(burrau=0.92, eq_rot=0.69, eq_fast=1.00),
    2.0:  dict(burrau=0.92, eq_rot=0.49, eq_fast=0.93),
    4.0:  dict(burrau=0.90, eq_rot=0.24, eq_fast=0.55),
    8.0:  dict(burrau=0.80, eq_rot=0.12, eq_fast=0.50),
    20.0: dict(burrau=0.46, eq_rot=0.09, eq_fast=0.42),
}
CONFIGS = ['burrau', 'eq_rot', 'eq_fast']


def win_shares(recs, dom_KE, thr, jf=0.5):
    """Winner share per config. `dom_KE` is the KE normalisation divisor."""
    out = {}
    for cfg in CONFIGS:
        wins = {c: 0 for c in xp_reduce.CONTRIBUTORS}
        tot = 0
        for r in recs:
            if r['config'] != cfg or r['jf'] != jf:
                continue
            for f in xp_reduce.footprint_stats(r, thr)['footprints']:
                v = {'shape': f['shape_raw'] / 2.0,
                     'event': f['event_norm'],
                     'KE':    f['KE_raw'] / dom_KE}
                m = max(v.values())
                wins[[c for c, x in v.items() if x >= m - 1e-15][0]] += 1
                tot += 1
        out[cfg] = {c: wins[c] / max(tot, 1) for c in wins} | {'n': tot}
    return out


if __name__ == '__main__':
    recs = [x for x in json.load(open('xp_results/exp1_raw.json')) if not x.get('_failed')]
    print(f"reduction path check: {len(recs)} probes, gate 1e-3, jf=0.5\n")
    print("| dom_KE | config | reproduced | REPORT.md | match |")
    print("|---|---|---|---|---|")
    allok = True
    for dom, exp in EXPECTED.items():
        ws = win_shares(recs, dom, 1e-3)
        for cfg in CONFIGS:
            got = ws[cfg]['KE']
            ok = abs(got - exp[cfg]) <= 0.005
            allok &= ok
            print(f"| /{dom} | {cfg} | {got:.4f} | {exp[cfg]:.2f} | {'ok' if ok else '**MISMATCH**'} |")
    print(f"\nREGRESSION CONTROL: {'PASS' if allok else 'FAIL'}")
