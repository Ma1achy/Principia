"""EXPERIMENT C driver: is a canonical-unit eps gauge-covariant?"""
import json, numpy as np, xp_scale, xp_common, tb

ALPHAS = [0.25, 1.0, 4.0]
MODES = ['absolute', 'initial', 'comoving']
C_EPS, DT0, T0 = 0.05, 1e-4, 5.0
REGIONS = [('burrau', 'near-field', 1.0, 3.0, 0), ('burrau', 'mid-field', 1.0, 6.0, 0)]


def run(cfg, cx, cy, bd, alpha, mode, dt=DT0, t=T0):
    xp_common.apply_config(cfg)
    r0, v0, gid, _, _ = tb.burrau_grid(3, 3, cx, cy, 0.05, body=bd, ens=3,
                                       jitter_frac=0.5, seed=0)
    if xp_common.CONFIGS[cfg]['omega'] != 0.0:
        v0 = xp_common.rigid_rotation(r0, xp_common.CONFIGS[cfg]['omega'])
    rs, vs = xp_scale.rescale(r0, v0, alpha)
    # eps: 'absolute' keeps the same physical length regardless of alpha (gauge
    # broken by construction); 'initial'/'comoving' take c as dimensionless.
    c = C_EPS if mode != 'absolute' else C_EPS * xp_scale.Rg(r0).mean()
    o = xp_scale.integrate_soft(rs, vs, t_max=t*alpha**1.5, dt=dt*alpha**1.5,
                                c_eps=c, mode=mode)
    import refine_test as R
    n = R.shape_vec(o['r'])
    mad = lambda x: 1.4826*np.median(np.abs(x - np.median(x)))
    er = np.median([mad(o['E1'][gid == k])/max(mad(o['E0'][gid == k]), 1e-300)
                    for k in range(9)])
    return dict(alpha=alpha, mode=mode, region=f"{cfg}/{cx},{cy}",
                # scale-quotiented invariants: E*alpha, Lz/alpha^0.5, n-hat
                E_q=float(np.median(o['E1'])*alpha),
                L_q=float(np.median(o['L1'])/np.sqrt(alpha)),
                nhat0=float(np.median(n[:, 0])),
                drift=float(np.median(np.abs((o['E1']-o['E0'])/o['E0']))),
                error_ratio=float(er))


if __name__ == '__main__':
    rows = []
    for cfg, name, cx, cy, bd in REGIONS:
        for mode in MODES:
            for a in ALPHAS:
                r = run(cfg, cx, cy, bd, a, mode)
                r['region_name'] = name
                rows.append(r)
                print(f"{name} {mode:9s} alpha={a:<5} E_q={r['E_q']:+.10f} "
                      f"L_q={r['L_q']:+.10f} nhat0={r['nhat0']:+.10f} "
                      f"drift={r['drift']:.2e} er={r['error_ratio']:.6f}", flush=True)
        json.dump(rows, open('xp_results3/expC_scale.json', 'w'), indent=1)
    # step-size sensitivity: a wrong equation does not improve with dt
    print("\nstep-size sensitivity (mid-field, alpha=1):", flush=True)
    extra = []
    for mode in MODES:
        for dt in [DT0, DT0/5]:
            r = run('burrau', 1.0, 6.0, 0, 1.0, mode, dt=dt)
            extra.append(dict(r, dt=dt))
            print(f"  {mode:9s} dt={dt:g} drift={r['drift']:.3e} er={r['error_ratio']:.6f}", flush=True)
    json.dump(rows + extra, open('xp_results3/expC_scale.json', 'w'), indent=1)
    print("EXP C DONE", flush=True)
