"""
EXPERIMENT 1 -- which exponential wall binds: measurement or representability?

Both walls are eta-independent, so tolerance cannot separate them. The jitter can:

    measurement horizon    t_m = ln(R/delta)/lambda     -- DECREASES with delta
    representability       t_r = ln(R/eps)/lambda       -- FIXED, no delta at all

There is a third possibility the brief's framing does not name, and the pilot says it is
the one that governs alpha_E. sigma_E(0) is proportional to delta (measured: exactly 4x
per 4x, to machine precision -- each trajectory conserves its own E, so the ensemble's
energy spread is set purely by the jitter). Numerical error in E grows as eps*e^(lambda t).
alpha_E departs from 1 when the second overtakes the first:

    t_E = ln(delta/eps)/lambda                          -- INCREASES with delta

Same log-of-a-ratio form, same eta-independence, same "moves with jitter" signature -- but
the opposite sign. So "does it move" does not settle it; the SIGN does. Predicted here:
+ln(2)/lambda = +0.69 per DOUBLING of jitter (later, not earlier).

Design: 5 jitter fractions spanning 16x at fixed quad size, so delta varies and nothing
else does. alpha_E from adjacent pairs (each a clean 2x lever) at the pair's geometric-mean
delta. Also record the shape spread, which is where the measurement horizon should live.
No gate anywhere; every footprint keeps all E+1 copies.
"""
import json, os, time
import numpy as np
import xp_nogate

REGIONS = [
    ('burrau', 'near-field', 1.0,  3.0, 0),
    ('burrau', 'mid-field',  1.0,  6.0, 0),
    ('burrau', 'body2 core', 1.0, -1.0, 2),
]
JF = [0.03125, 0.0625, 0.125, 0.25, 0.5]          # 16x span
HORIZONS = [13.0, 20.0, 24.0, 27.0, 30.0, 33.0, 36.0, 40.0]
PATH = 'xp_results4/exp1_jitter.json'


def n_sync_for(t):
    return max(32, int(round(t / 0.4)))


if __name__ == '__main__':
    recs = json.load(open(PATH)) if os.path.exists(PATH) else []
    done = {(r['config'], r['cx'], r['cy'], r['t'], r['jf']) for r in recs}
    i, total = 0, len(REGIONS)*len(JF)*len(HORIZONS)
    for t in HORIZONS:
        for cfg, name, cx, cy, bd in REGIONS:
            for jf in JF:
                i += 1
                if (cfg, cx, cy, t, jf) in done:
                    print(f"[{i}/{total}] cached", flush=True); continue
                t0 = time.time()
                r = xp_nogate.run_probe(config=cfg, cx=cx, cy=cy, body=bd,
                                        half=0.05, jf=jf, t=t, ens=7, eta=0.01,
                                        n_sync=n_sync_for(t))
                r['_seconds'] = round(time.time()-t0, 1)
                r['_region'] = name
                recs.append(r)
                json.dump(recs, open(PATH, 'w'))          # flush every probe
                er = xp_nogate.error_ratios(r)
                sE = float(np.mean(xp_nogate.footprint_values(r, 'E', xp_nogate.d_mad)))
                print(f"[{i}/{total}] t={t:.0f} {name} jf={jf:<8g} {r['_seconds']}s "
                      f"sigE={sE:.4e} er={er['error_ratio']:.4g} nf={er['nonfinite']:.3f}",
                      flush=True)
    print("EXP 1 DONE", flush=True)
