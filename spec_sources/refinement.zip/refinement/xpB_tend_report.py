"""Experiment C tables: t_end exponent with bisected escape times."""
import json, numpy as np, estimators, xp_reduce

recs = json.load(open('xp_results2/expC_tend.json'))
THR = 1e-4
NAME = {(1.0,6.0):'mid-field',(1.0,-5.0):'body2 mid',(0.0,1.0):'b0 core',
        (-1.0,-0.5):'b1 core',(1.0,-0.5):'b2 core',(1.0,3.0):'near-field'}


def spreads(r, escaped_only=True):
    gid = np.asarray(r['gid']); good = np.asarray(r['drift'], float) < THR
    if escaped_only:
        good = good & ~np.asarray(r['censored'], bool)
    te = np.asarray(r['t_end'], float); E = np.asarray(r['E_fin'], float)
    st, sE, nfp, nres = [], [], 0, 0
    for k in range(int(gid.max())+1):
        s = np.nonzero((gid == k) & good)[0]
        if len(s) < 3:
            continue
        nfp += 1
        nres += (len(np.unique(te[s])) > 1)
        st.append(np.std(te[s])); sE.append(np.std(E[s]))
    return (float(np.mean(st)) if st else np.nan,
            float(np.mean(sE)) if sE else np.nan, nfp, nres)


print("## C1. Resolution recovered by decoupling the escape cadence\n")
print("| config | region | t | half | resolution | fp resolved /16 | esc frac | retained | t_end spread |")
print("|---|---|---|---|---|---|---|---|---|")
for r in recs:
    sp, sE, nfp, nres = spreads(r)
    good = np.asarray(r['drift'], float) < THR
    print(f"| {r['config']} | {NAME[(r['cx'],r['cy'])]} | {r['t']:.0f} | {r['half']} | "
          f"{r['resolution']:.2e} | {nres}/16 | {1-np.mean(r['censored']):.2f} | "
          f"{good.mean():.2f} | {sp:.4e} |")

print("\n## C2. t_end exponent, parent (0.05) vs child (0.025)\n")
print("| config | region | t | spread P | spread C | **alpha t_end** | alpha_E control | trust |")
print("|---|---|---|---|---|---|---|---|")
seen = set()
for r in recs:
    k = (r['config'], r['cx'], r['cy'], r['t'])
    if k in seen:
        continue
    seen.add(k)
    P = next((x for x in recs if (x['config'],x['cx'],x['cy'],x['t'])==k and x['half']==0.05), None)
    C = next((x for x in recs if (x['config'],x['cx'],x['cy'],x['t'])==k and x['half']==0.025), None)
    if not P or not C:
        continue
    sp, sE, _, _ = spreads(P); sc, sEc, _, _ = spreads(C)
    d = np.array([C['delta'], P['delta']])
    a  = estimators.est_ols(d, np.array([sc, sp]))
    aE = estimators.est_ols(d, np.array([sEc, sE]))
    tr = 'ok' if xp_reduce.trustworthy(aE) else '**UNTRUSTWORTHY**'
    print(f"| {r['config']} | {NAME[(r['cx'],r['cy'])]} | {r['t']:.0f} | {sp:.4e} | {sc:.4e} | "
          f"**{a:.4f}** | {aE:.4f} | {tr} |")

print("\n## C3. Control computed on ALL gated copies vs ESCAPED-ONLY (the Brief 1 caveat)\n")
print("Restricting to escaped copies makes the surviving subset depend on the")
print("perturbation size, which breaks the linearity alpha_E assumes.\n")
print("| config | region | t | alpha_E escaped-only | alpha_E all gated | difference |")
print("|---|---|---|---|---|---|")
for k in sorted(seen):
    P = next((x for x in recs if (x['config'],x['cx'],x['cy'],x['t'])==k and x['half']==0.05), None)
    C = next((x for x in recs if (x['config'],x['cx'],x['cy'],x['t'])==k and x['half']==0.025), None)
    if not P or not C:
        continue
    d = np.array([C['delta'], P['delta']])
    _, sE_e, _, _ = spreads(P); _, sEc_e, _, _ = spreads(C)
    _, sE_a, _, _ = spreads(P, False); _, sEc_a, _, _ = spreads(C, False)
    ae = estimators.est_ols(d, np.array([sEc_e, sE_e]))
    aa = estimators.est_ols(d, np.array([sEc_a, sE_a]))
    print(f"| {k[0]} | {NAME[(k[1],k[2])]} | {k[3]:.0f} | {ae:.4f} | {aa:.4f} | {abs(ae-aa):.4f} |")
