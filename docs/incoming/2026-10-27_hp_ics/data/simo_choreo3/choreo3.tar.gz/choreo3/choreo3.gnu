set nokey;set ter x11;set pointsize 2;set size ratio -1/sqrt(2.)
#set xtics -10,.2,10;set ytics -10,.2,10 : comentada en asus
if (c<0) c=0
c=int(c)
if (a<1) a=1
if (a>345) a=345
a=int(a)
if (b<1) b=1
if (b>345) b=345
b=int(b)
d=-1
if (a<=b) d=1
n=a-1
m=b-1
load 'loop.gnu'
