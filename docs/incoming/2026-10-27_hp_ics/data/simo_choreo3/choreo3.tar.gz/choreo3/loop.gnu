plot 'dat.orb' ev :::n::n u 1:2 w l,''ev :::n::n u 3:4 w l,'' ev :::n::n u (-$1-$3):(-$2-$4) w l,'dat.cir' ev ::0:n:0:n w p 9,'' ev ::1:n:1:n w p 3,'' ev ::0:n:0:n u 3:4 w p 9,'' ev ::1:n:1:n u 3:4 w p 3,'' ev ::0:n:0:n u (-$1-$3):(-$2-$4) w p 9,'' ev ::1:n:1:n u (-$1-$3):(-$2-$4) w p 3
print "Case ",n+1
pause c
if (n==m)print"final requested choreography displayed";n=1000;exit
# l'exit de la linia anterior no fa efecte a asus; per aixo poso el n=1000
n=n+d;reread
