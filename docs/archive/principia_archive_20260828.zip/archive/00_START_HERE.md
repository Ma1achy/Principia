# Principia — archive index

Everything produced in this working session, organised by kind. Read in this order if you're
picking this up cold.

## Reading order

1. **`00_philosophy_and_pitfalls/`** — start here.
   - `principia_00_philosophy.md` — the core philosophy: the atlas/inspector/prebake three-rung
     model, the six commitments, what's parked and why, what's been considered and rejected.
   - `principia_01_pitfalls.md` — the patchwork bug write-up (observed behaviour, four wrong
     theories, the controlled experiment that settled it, the real bug, the new escape
     criterion) and the standing rules earned from it.

2. **`01_contracts_and_specs/`** — the stable interface documents. Each `*_contract.md` defines
   a boundary (rendering, scheduling, caching, parity, the integrator occupant slot, the chart
   decoder, GUI state) that downstream work is expected to honour.

3. **`02_design_docs/`** — the `dd_*` (design decision) family plus supporting notes: decoder
   maths, colouring, the SimState payload layout, predictability horizon, memory tiers, deep
   zoom, GPU determinism, the chart reference (§0-5 maths for every chart family), validation
   orbits, and the tree-dump analysis.

4. **`03_briefs/`** — self-contained instructions written for an agent to build against. Each
   is meant to be handed over with no other context. Includes the kernel build brief, the
   scheduler build brief, the structure-criterion brief, the signal audit brief.

5. **`04_experiment_reports/`** — the four external Claude Code experiment reports on the
   refinement criterion (headline findings incorporated into the design docs above).

6. **`05_reference_code/`** — every NumPy reference implementation. `tb.py` is the physics
   core; `tb_az.py` is Aarseth-Zare (validated, but carries the dtau-per-interval and
   overshoot bugs described in the pitfalls doc — see `tb_az_overshoot_fix.py` for the patched
   step-clamp); `refine_test.py` has the shape_vec (Hopf map) implementation; `glsl_port.py`
   and `principia_glsl_reference_port.py` port the GLSL reference decode/integrator;
   `principia_escape_criterion_ref.py` has the closure-based escape criterion with the
   stop-on-escape toggle; `principia_prnq_parser.py` reads prin-rs's binary tree dumps.

7. **`06_figures/`** — every generated PNG from every experiment: the checkerboard/SSAA tests,
   refinement diagnosis figures, the dtau bug investigation (drift maps, before/after pairs,
   integrator comparison matrices), the config chart diagram, the GLSL-vs-AZ comparisons.

8. **`07_json_and_raw_data/`** — raw JSON/binary artefacts from the experiment rounds, where
   present at the top level (most raw data lives under `10_prior_xp_results/`).

9. **`08_scratchpads/`** — working notes, not polished: the IC inspector scratchpad and the
   validation scratchpad.

10. **`09_kernel_build/`** — the self-contained handoff package for the Rust kernel build:
    `BRIEF.md` plus the `reference/` folder of NumPy modules with a smoke test.

11. **`10_prior_xp_results/`** — raw compute artefacts from three-plus rounds of external
    experiments (refinement probe, xp_results through xp_results4): harness code, raw JSON,
    and intermediate reports.

## What this is not

This is a snapshot of design documents and reference code, not the prin-rs Rust
implementation itself — that lives at github.com/Ma1achy/prin-rs and is not duplicated here.
Nothing in this archive is a substitute for that repository's own history; it's the
surrounding design record, the reasoning, and the reference implementations everything there
was checked against.

## Known-important cross-references

- The **dtau step-control bug** and its two contributing causes (fixed-per-interval sizing,
  and the sync-boundary overshoot) are documented in `00_philosophy_and_pitfalls/principia_01_pitfalls.md`
  and demonstrated in the `06_figures/principia_dtau_*` and `principia_collision_*` /
  `principia_integrator_matrix.png` images.
- The **new escape criterion** (closure + energy, replacing the four-condition heuristic) is
  specced in the pitfalls doc §2 and implemented in `05_reference_code/principia_escape_criterion_ref.py`.
- The **chart maths** (masses, hyperspherical Jacobi decode, momentum construction, shape
  sphere, Burrau family) is in `02_design_docs/principia_chart_reference.md`.
