# Principia design corpus — for the prin-rs agent

**Everything the design says, as of the vertical slice being closed.** The vertical slice
(`prin-rs`) is the evidence base; this is the design it fed back into.

## Read in this order

1. **`00_read_first/principia_INDEX.md`** — the map. Start here.
2. **`00_read_first/principia_00_philosophy.md`** — what the instrument is *for*, and the six
   commitments. Return here when a decision feels arbitrary.
3. **`00_read_first/principia_01_pitfalls.md`** — eight named failure patterns, each with the
   measurement that produced it. Most of them came from `prin-rs`.

## Folders

| | |
|---|---|
| `01_contracts/` | the interfaces. `canonical_spec` indexes which doc owns what. `spec_pending_changes` records twelve deltas; **7, 8, 10, 11, 12 have landed** |
| `02_design_physics/` | charts, decoder, payload, integrator, horizon, deep zoom, coordinates |
| `03_design_allocation/` | **`principia_dd_refinement_policy.md`** — `Policy::Tolerance`. The current refinement design, v0.5 |
| `04_design_rings/` | the cross-cutting services: architecture, telemetry/tiers, colour, memory, pointer channels, image embedding |
| `05_reference_code/` | NumPy references. `tb.py` is the physics core; `principia_escape_criterion_ref.py` has the closure+energy criterion; `principia_pxpack2_robust.py` the LSB embedding; `principia_prnq_parser.py` reads tree dumps |
| `06_figures/` | every generated figure from the investigations |
| `07_archive/` | **record only — do not implement from these.** Each carries a header saying what happened and what replaced it |
| `08_scratchpads/` | working notes, explicitly provisional |

## What changed because of the vertical slice

- **Heggie is the default regularisation**, not Aarseth–Zare. Regularisation is a **second
  swappable axis**, independent of the stepper.
- **The escape criterion is closure + energy.** The old test fired on transients — 0 of 895 still
  unbound eight boundaries later.
- **The wedge artefacts were the predictive step limit**, not the `dtau` fix. Two artefacts, never
  one defect.
- **The refinement policy is `Policy::Tolerance`**, and **`error(B)` scored in OKLab is void** —
  it made breadth-first optimal by construction of the metric.
- **The tier model is three coupled axes** — `eps`, frame budget, hard cap — with the binding one
  reported. Numbers are placeholders pending device calibration.

## What is open

See the end of `principia_INDEX.md`. The largest: **the discrete parity surface has never been
tested across backends**, and everything in the plan sits on "one kernel, several backends".
