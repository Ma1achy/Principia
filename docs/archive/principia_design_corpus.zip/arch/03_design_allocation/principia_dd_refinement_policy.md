# Refinement policy — `Policy::Tolerance`

**Status: v0.5. Works, failure modes measured, two known defects.** Settled enough to build on;
expected to improve in the real build.

**Evidence base:** `prin-rs` — `FINDINGS.md` §5 (the policy), `README.md` §7 (the scheduler),
`results/tolerance_scaling/README.md` (where the saving does and does not generalise).

**Supersedes** `principia_ARCHIVE_dd_refinement_criterion_v0.md` and
`principia_ARCHIVE_dd_tree_dump_analysis_v0.md`. Read those only for method and for the record of
how the answer was reached; **do not implement from them.**

---

## 0. What the mechanism is actually for

**Progressive display, and arbitrary zoom. The compute saving is a bonus and is not the argument.**

This was misread for a long stretch, including in this corpus. The quadtree's value is:

1. **Time to first frame.** The root quad is `N² = 64` footprints — effectively instant. You see the
   slice immediately and it sharpens. That is what makes tilting and slicing feel responsive, and it
   is **independent of what the total saving turns out to be**.
2. **Arbitrary zoom.** A uniform grid cannot zoom past its own resolution. The adaptive tree plus the
   linearised decoder (`principia_deep_zoom.md`) reaches depth ~50. **This is the feature; the tree
   exists for it.**
3. **Total compute**, which varies enormously by slice and is the subject of §5.

> A frame does not have to converge within the frame budget. **The application has to stay
> responsive** — show something immediately, keep improving. Those are different requirements and
> only the second is a hard constraint.

---

## 1. The split rule — no exponent in the split test

```
split(quad)  ⟺  any footprint f in quad is unresolved

unresolved(f)  ⟺  spread_shape(f) > eps          the payload has not settled
                ∨  the copies disagree on event class
                ∨  the footprint is undetermined  (non-finite spread, or an unusable copy)
```

**`eps` is a tolerance in `spread_shape`'s own units** — the same units in every region. The previous
policy's threshold had to sit *inside a distribution whose median moves six orders between regions*,
which is why it needed per-region tuning and never got it right.

**`eps` is the user-facing quality knob.** Tier tables key off it, not off resolution.

---

## 2. The stop rule — `alpha_area` is a DIMENSION, not a tuned constant

A fractal region is unresolved at every level and would descend forever. The stop is an exponent on
the quantity the policy actually optimises — the **unresolved area**:

```
alpha_area = log2( unresolved_area(coarse) / unresolved_area(children) )
```

**A line reads 1. A sea reads 0. A boundary of box dimension `d` reads `2 − d`.** So `alpha_lo` is a
*dimension threshold*, which satisfies the derive-or-absent rule — and it means **the scheduler can
report a measured box dimension as a by-product**, which is a Paper 2 quantity falling out of the
renderer for free.

Shipped default **`alpha_lo = 0.005`**: floor only where the children resolved essentially nothing,
judged as no-gain at a noise margin rather than as a dimension cut. At `0.2` the same floor costs
**11% of `config_stability`'s resolvable pixels** and puts its tree *above* uniform at its own error.

### 2.1 Two structural details, each of which cost a measurement

**The exponent is judged over TWO levels, from the grandparent's quadrant.** A footprint cell on a
quad boundary is shared by both quads at half weight, while the finer grid below locates the same
structure on one side at full weight — so a shore in an edge cell reads *no gain* on one side and
*infinite* gain on the other, and its children floor. From the grandparent's quadrant, whose cells
split cleanly at the midlines: **min 1.00, max 1.05 over 15 splits, against 0 under the one-level
form.** This is a constraint on the tree walk, not an optimisation.

**Noise is told from structure by NEIGHBOUR AGREEMENT, per footprint** — not by a coherence statistic
with a base rate in it. An unresolved footprint counts as structure iff **at least two of its eight
neighbours share its class and land within ~11° on the shape sphere**. A sea's neighbours are
independent draws, so two agreeing by chance is a few in ten thousand. Calibrated on white noise and
nearly inert on real charts, where seas are coherent sponges rather than white: it floors **2–37
quads where the dimension floor floors 262–334**.

### 2.2 TWO KNOWN DEFECTS IN `alpha_area` — both open

**It cannot tell an empty mask from a full one.** Both return exactly `0.0000`, so any positive
`alpha_lo` floors on either. This is a **can't-fail test inside the floor itself**, and it costs
`near-field` its `t = 50` descent: 21 quads at error 0.103 with 93% of the frame resolvable, against
829 quads at error 0.00000 with `alpha_lo = 0`.

**The exponent goes negative on sea charts at tight `eps`** (−0.020 to −0.076 at `eps = 1e-3`): the
children found *more* unresolved area than the parent, so `d = 2 − α` reads **above 2 — impossible in
the plane**. The dimension interpretation has lapsed and **the floor fires anyway, hardest where
refinement is discovering structure.** Worst possible failure direction.

---

## 3. Merging — the split rule read backwards

Under a live playhead the field changes as `t` advances, so the tree must **coarsen**:

> A parent whose four children are all leaves that did not split this boundary is **merged back** when
> the parent has become resolved (`Keep`) or its split shows no gain (`Floor`).

Children become `Decision::Merged`. **`QuadTree::resident` — what a live design actually holds — is
tracked separately from `quads_computed`.** On a moving-pulse fixture, resident runs 37 → 85 → 37 → 69
while 181 quads are computed, and the final tree is **bitwise the static tree at the horizon.**

A merged parent remembers its exponents so it is not re-split into the same four children every
boundary; the memory expires when the quad's structured weight leaves a factor of two of where the
split was judged.

**Two subtleties, both measured:**

- **Expiring a memory by DELETING it is the opposite of expiring it.** `decide` reads *no memory* as
  *never merged for no gain*, so clearing reverts to first-time behaviour and floors **more**, not
  less — 421 quads against 645. A separate expiry flag is required, and **an `assert_ne!` cannot tell
  the two apart.**
- **A capped leaf must stay re-decidable.** A leaf stopped by the camera floor originally left the
  frontier permanently, so a parent that later resolved could never merge it — **149 quads against a
  static 69, finer rather than coarser.** Caps are re-tested every boundary, because a resolved quad
  is decided *ahead* of the caps.

---

## 4. THE METRIC MUST BE PAYLOAD-SPACE. THIS IS NOT OPTIONAL.

**`error(B)` scored in OKLab is void**, and every conclusion drawn from it with it.

The shipping colouring auto-ranges lightness **per region**. So a smooth region's `1e-8` residual
counted as error at every depth, and **breadth-first came out near-optimal by construction of the
metric**. That is the entire explanation for the long-standing "nothing beats uniform" result.

**Score on the payload:** `shape_vec` and event class, against a fixed `eps` in `spread_shape`'s own
units. Shader-agnostic — which is what the architecture wanted anyway, and it resolves the tension
between "refinement must be shader-independent" and "the metric is a colour distance".

**Any future criterion work scored in render space is void before it starts.**

---

## 5. WHERE THE SAVING GENERALISES — and where it does not

**The saving is a property of the FIELD, not of the policy.** Measured across four charts, three
horizons, three tolerances:

| | tolerance vs uniform |
|---|---|
| Burrau regions (`near-field`, `deep interior`) | **5–37×** |
| `config_stability`, `tilt_plambda` (arbitrary latent slices) | **~1×**, sometimes below |

**Read `dp/u` before `tol/u`. This is the methodological result the rest depends on.** A low saving
has two causes — *a field with nothing to find*, and *a policy failing to find it* — and **only the
exact optimum separates them.** Both occur on the same chart one decade of `eps` apart.

On the sea charts the **exact-optimum ceiling is 1.08–1.44×** over breadth-first in all 24 fixed-target
cells, at every horizon, and the policy sits at 1.10–1.45× of that. **It is not underperforming. The
optimum is breadth-first.**

**And that is not bad news for interactivity.** Breadth-first is exactly what progressive display
does — it improves the whole frame evenly, which is what you want while someone tilts. On those charts
the best refinement order and the best *display* order coincide.

### 5.1 `sea_fraction` is the regime test, and it is computable before any descent

`sea_fraction(eps)` is the footprint-spread CDF. Its sensitivity says whether the threshold sits **in
the bulk or in a gap** — and *failing to cut the bulk is what makes the policy simultaneously good and
untunable* on those charts.

**A cheap estimator that avoids needing a full cache is the concrete unbuilt next step.** It would let
the system know which regime a slice is in *before* descending, which affects tiering, budget
prediction, and possibly the UI.

### 5.2 The tolerance is inert exactly where the policy works

`deep interior` returns **the same quad count at all three tolerances at all three horizons** —
225/225/225, 313/313/313, 309/309/309 — while delivering the grid's best saving, 16.3–18.6×. The sea
charts, where the policy delivers least, are the **most** tolerance-sensitive.

**Two causes of an inert `eps`, separated by the sea span:** a frozen tree with a *frozen*
`sea_fraction` is a gap in the field; a frozen tree with a *moving* `sea_fraction` is **another stop
overriding the tolerance** — `near-field` at `t = 50`, bitwise one tree while `sea_fraction` runs
0.0479 → 0.1011.

**`tau` is a second threshold and is not `eps` times a constant.** The working value ran `eps`,
`eps/10`, `eps/100` across `t = 13, 23, 50` on one chart, and `eps/3.3` over-refines `deep interior`
by 2.4× for no error gain. **Calibration moves cells by an order** — `near-field` at `t=13, eps=1e-3`
runs 0.30× at `tau=eps` and **15.26×** at `tau=eps/3.3`.

---

## 6. Decision variants, and the second budget line

`Keep`, `Split`, `Floor`, `ScreenFloor`, `Undetermined`, `Collapsed`, `Merged`, `BalanceForced`.

> **`Undetermined` means FINER `eta`, NOT FINER CELLS.** That is a **second refinement axis** and
> nothing in the architecture currently has one. It measured **exactly 0.0000 in all 36 cells** of the
> tolerance grid — but that is a property of the **shipped step control**, not of the policy. A chart
> that still integrates badly reintroduces it, and the budget model would then need two lines.

**Report the stop-reason breakdown WEIGHTED BY THE SUBTREE EACH STOP FORECLOSES.** Only **4 leaves**
read `floor` at level 2 in the `near-field` case — each foreclosing a quarter of the frame, suppressing
a descent that reaches 829 quads at zero error. **A decisive stop reads as a rounding error in a leaf
count.** This extends the standing rule (never quote a leaf count without its stop breakdown).

---

## 7. Open

- **The two `alpha_area` defects** (§2.2). Both are bugs with reproductions.
- **A cheap `sea_fraction` estimator** (§5.1) — the named next step.
- **Depth beyond level 6.** Every tree in the tolerance study is capped; nothing is known past it.
- **A calibrated grid.** All 36 cells ran shipped defaults; a calibrated `tau` moves several by an
  order.
- **The live playhead.** The tolerance study is static descents. Merging is measured on a pulse
  fixture but not under real camera motion.
- **Camera integration.** `Camera::veto` is position-free by design (correct — it keeps a quad's
  *decision* independent of where the camera points). Position belongs in **priority**, and priority
  is not wired. Until it is, a pan measures an identity.
